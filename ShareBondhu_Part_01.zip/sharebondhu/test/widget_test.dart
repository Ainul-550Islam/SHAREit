import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sharebondhu/main.dart';
import 'package:sharebondhu/models/share_file.dart';

ShareFile sampleFile({
  String name = 'notes.pdf',
  String path = '/picked/notes.pdf',
  int size = 1536,
  Stream<List<int>> Function()? openRead,
}) {
  return ShareFile(
    name: name,
    size: size,
    sourceUri: Uri.file(path),
    readStream: openRead ?? () => Stream<List<int>>.value(<int>[1, 2, 3]),
  );
}

Future<void> mountApp(
  WidgetTester tester,
  PickShareFiles picker, {
  Size size = const Size(390, 844),
}) async {
  tester.view.physicalSize = size;
  tester.view.devicePixelRatio = 1;
  tester.binding.platformDispatcher.platformBrightnessTestValue =
      Brightness.light;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);
  addTearDown(
    tester.binding.platformDispatcher.clearPlatformBrightnessTestValue,
  );
  await tester.pumpWidget(ShareBondhuApp(pickFiles: picker));
  await tester.pumpAndSettle();
}

Future<void> tapSelect(WidgetTester tester) async {
  final button = find.byKey(const ValueKey('select-files-button'));
  await tester.ensureVisible(button);
  await tester.pumpAndSettle();
  await tester.tap(button);
  await tester.pumpAndSettle();
}

Future<void> tapNavigation(WidgetTester tester, String key) async {
  await tester.tap(find.byKey(ValueKey(key)));
  await tester.pumpAndSettle();
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  WidgetController.hitTestWarningShouldBeFatal = true;

  group('File model', () {
    test('formats bytes with binary units', () {
      expect(formatBytes(0), '0 B');
      expect(formatBytes(1023), '1023 B');
      expect(formatBytes(1024), '1 KiB');
      expect(formatBytes(1536), '1.5 KiB');
      expect(formatBytes(1048576), '1 MiB');
      expect(formatBytes(9663676416), '9 GiB');
    });

    test('rejects negative byte counts', () {
      expect(() => formatBytes(-1), throwsArgumentError);
      expect(() => sampleFile(size: -1), throwsArgumentError);
    });

    test('classifies file extensions without case sensitivity', () {
      expect(sampleFile(name: 'PHOTO.JPEG').category, FileCategory.image);
      expect(sampleFile(name: 'clip.mp4').category, FileCategory.video);
      expect(sampleFile(name: 'song.flac').category, FileCategory.audio);
      expect(sampleFile(name: 'slides.pptx').category, FileCategory.document);
      expect(sampleFile(name: 'backup.7z').category, FileCategory.archive);
      expect(sampleFile(name: 'package.apk').category, FileCategory.other);
    });

    test('handles dotfiles and names without extensions', () {
      expect(sampleFile(name: '.gitignore').extension, '');
      expect(sampleFile(name: 'README').extension, '');
      expect(sampleFile(name: 'trailing.').extension, '');
      expect(sampleFile(name: 'report.final.PDF').extension, 'pdf');
    });

    test('keeps source identity separate from the display name', () {
      final first = sampleFile(name: 'notes.pdf', path: '/one/notes.pdf');
      final second = sampleFile(name: 'notes.pdf', path: '/two/notes.pdf');
      expect(first.name, second.name);
      expect(first.id, isNot(second.id));
    });

    test('does not read file content until a stream is requested', () async {
      var readCount = 0;
      final file = sampleFile(
        size: 3,
        openRead: () {
          readCount += 1;
          return Stream<List<int>>.value(<int>[1, 2, 3]);
        },
      );
      expect(file.formattedSize, '3 B');
      expect(file.categoryLabel, 'Document');
      expect(readCount, 0);
      final content = await file.openRead().expand((chunk) => chunk).toList();
      expect(content, <int>[1, 2, 3]);
      expect(readCount, 1);
      await file.openRead().drain<void>();
      expect(readCount, 2);
    });

    test('validates filenames and URI schemes', () {
      expect(() => sampleFile(name: '  '), throwsArgumentError);
      expect(
        () => ShareFile(
          name: 'notes.pdf',
          size: 3,
          sourceUri: Uri.parse('relative-file'),
          readStream: () => const Stream<List<int>>.empty(),
        ),
        throwsArgumentError,
      );
    });

    test('freezes selection results and validates unavailable counts', () {
      final original = <ShareFile>[sampleFile()];
      final selection = FileSelection(files: original);
      original.clear();
      expect(selection.files, hasLength(1));
      expect(() => selection.files.clear(), throwsUnsupportedError);
      expect(
        () => FileSelection(files: <ShareFile>[], unavailableCount: -1),
        throwsArgumentError,
      );
    });
  });

  group('Part 1 user interface', () {
    testWidgets('starts with the brand and an empty selection', (tester) async {
      await mountApp(tester, () async => FileSelection(files: <ShareFile>[]));
      expect(find.text('ShareBondhu'), findsOneWidget);
      expect(find.text('Select files'), findsOneWidget);
      expect(find.byKey(const ValueKey('selected-count')), findsOneWidget);
      final count = tester.widget<Text>(
        find.byKey(const ValueKey('selected-count')),
      );
      expect(count.data, '0');
      expect(find.text('Transfer complete'), findsNothing);
      expect(tester.takeException(), isNull);
    });

    testWidgets('selects several files and calculates the total', (
      tester,
    ) async {
      final files = <ShareFile>[
        sampleFile(),
        sampleFile(name: 'photo.jpg', path: '/picked/photo.jpg', size: 512),
      ];
      await mountApp(tester, () async => FileSelection(files: files));
      await tapSelect(tester);
      expect(find.text('notes.pdf'), findsOneWidget);
      expect(find.text('photo.jpg'), findsOneWidget);
      expect(find.text('2 files · 2 KiB'), findsOneWidget);
      expect(find.text('Added 2 files.'), findsOneWidget);
      expect(find.text('Transfer complete'), findsNothing);
    });

    testWidgets('skips duplicate source references in one selection', (
      tester,
    ) async {
      final file = sampleFile();
      await mountApp(
        tester,
        () async => FileSelection(files: <ShareFile>[file, file]),
      );
      await tapSelect(tester);
      expect(find.text('notes.pdf'), findsOneWidget);
      expect(find.text('1 file · 1.5 KiB'), findsOneWidget);
      expect(
        find.text('Added 1 file. 1 duplicate reference skipped.'),
        findsOneWidget,
      );
    });

    testWidgets('skips duplicate source references across picker calls', (
      tester,
    ) async {
      final file = sampleFile();
      await mountApp(
        tester,
        () async => FileSelection(files: <ShareFile>[file]),
      );
      await tapSelect(tester);
      await tester.tap(find.byKey(const ValueKey('add-files-button')));
      await tester.pumpAndSettle();
      expect(find.text('1 file · 1.5 KiB'), findsOneWidget);
      expect(find.text('1 duplicate reference skipped.'), findsOneWidget);
    });

    testWidgets('keeps files that share a name but have different sources', (
      tester,
    ) async {
      await mountApp(
        tester,
        () async => FileSelection(
          files: <ShareFile>[
            sampleFile(path: '/one/notes.pdf'),
            sampleFile(path: '/two/notes.pdf'),
          ],
        ),
      );
      await tapSelect(tester);
      expect(find.text('notes.pdf'), findsNWidgets(2));
      expect(find.text('2 files · 3 KiB'), findsOneWidget);
    });

    testWidgets('preserves the selection when the picker is canceled', (
      tester,
    ) async {
      var calls = 0;
      await mountApp(tester, () async {
        calls += 1;
        return FileSelection(
          files: calls == 1 ? <ShareFile>[sampleFile()] : <ShareFile>[],
        );
      });
      await tapSelect(tester);
      await tester.tap(find.byKey(const ValueKey('add-files-button')));
      await tester.pumpAndSettle();
      expect(find.text('notes.pdf'), findsOneWidget);
      expect(find.text('1 file · 1.5 KiB'), findsOneWidget);
      expect(calls, 2);
    });

    testWidgets('removes a reference without reading its original file', (
      tester,
    ) async {
      var reads = 0;
      final file = sampleFile(
        openRead: () {
          reads += 1;
          return const Stream<List<int>>.empty();
        },
      );
      await mountApp(
        tester,
        () async => FileSelection(files: <ShareFile>[file]),
      );
      await tapSelect(tester);
      await tester.tap(find.byKey(ValueKey('remove:${file.id}')));
      await tester.pumpAndSettle();
      expect(find.text('0 files · 0 B'), findsOneWidget);
      expect(find.text('notes.pdf'), findsNothing);
      expect(reads, 0);
      expect(
        find.text('Removed from selection. Your original file is unchanged.'),
        findsOneWidget,
      );
    });

    testWidgets('asks before clearing and respects both dialog choices', (
      tester,
    ) async {
      await mountApp(
        tester,
        () async => FileSelection(files: <ShareFile>[sampleFile()]),
      );
      await tapSelect(tester);
      await tester.tap(find.byKey(const ValueKey('clear-selection-button')));
      await tester.pumpAndSettle();
      expect(find.text('Clear selection?'), findsOneWidget);
      await tester.tap(find.byKey(const ValueKey('keep-files-button')));
      await tester.pumpAndSettle();
      expect(find.text('notes.pdf'), findsOneWidget);
      await tester.tap(find.byKey(const ValueKey('clear-selection-button')));
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const ValueKey('confirm-clear-button')));
      await tester.pumpAndSettle();
      expect(find.text('0 files · 0 B'), findsOneWidget);
      expect(find.text('notes.pdf'), findsNothing);
    });

    testWidgets('shows unavailable-file feedback without losing valid files', (
      tester,
    ) async {
      await mountApp(
        tester,
        () async => FileSelection(
          files: <ShareFile>[sampleFile()],
          unavailableCount: 1,
        ),
      );
      await tapSelect(tester);
      expect(find.text('notes.pdf'), findsOneWidget);
      expect(
        find.text(
          'Added 1 file. 1 file was unavailable. Save locally and try again.',
        ),
        findsOneWidget,
      );
    });

    testWidgets('reports an entirely unavailable selection', (tester) async {
      await mountApp(
        tester,
        () async => FileSelection(files: <ShareFile>[], unavailableCount: 2),
      );
      await tapSelect(tester);
      expect(
        find.text('2 files were unavailable. Save locally and try again.'),
        findsOneWidget,
      );
      final count = tester.widget<Text>(
        find.byKey(const ValueKey('selected-count')),
      );
      expect(count.data, '0');
    });

    testWidgets('shows access errors and permits a successful retry', (
      tester,
    ) async {
      var calls = 0;
      await mountApp(tester, () async {
        calls += 1;
        if (calls == 1) {
          throw PlatformException(code: 'permission_denied');
        }
        return FileSelection(files: <ShareFile>[sampleFile()]);
      });
      await tapSelect(tester);
      expect(find.byKey(const ValueKey('selection-error')), findsOneWidget);
      expect(
        find.text(
          'File access was not allowed. You can try the system picker again.',
        ),
        findsOneWidget,
      );
      await tapSelect(tester);
      expect(find.byKey(const ValueKey('selection-error')), findsNothing);
      expect(find.text('notes.pdf'), findsOneWidget);
      expect(calls, 2);
    });

    testWidgets('reports missing native plugins with rebuild instructions', (
      tester,
    ) async {
      await mountApp(tester, () async => throw MissingPluginException());
      await tapSelect(tester);
      expect(find.textContaining('run flutter pub get'), findsOneWidget);
      await tester.tap(find.byKey(const ValueKey('dismiss-error-button')));
      await tester.pumpAndSettle();
      expect(find.byKey(const ValueKey('selection-error')), findsNothing);
    });

    testWidgets('handles an unexpected picker error without crashing', (
      tester,
    ) async {
      await mountApp(
        tester,
        () async => throw StateError('test picker failure'),
      );
      await tapSelect(tester);
      expect(
        find.text(
          'We could not read that selection. Try choosing locally stored files.',
        ),
        findsOneWidget,
      );
      expect(tester.takeException(), isNull);
    });

    testWidgets('prevents repeated picker calls while selection is pending', (
      tester,
    ) async {
      final pending = Completer<FileSelection>();
      var calls = 0;
      await mountApp(tester, () {
        calls += 1;
        return pending.future;
      });
      final button = find.byKey(const ValueKey('select-files-button'));
      await tester.ensureVisible(button);
      await tester.tap(button);
      await tester.pump();
      expect(find.byType(CircularProgressIndicator), findsOneWidget);
      expect(tester.widget<FilledButton>(button).onPressed, isNull);
      await tester.tap(button);
      await tester.pump();
      expect(calls, 1);
      pending.complete(FileSelection(files: <ShareFile>[sampleFile()]));
      await tester.pumpAndSettle();
      expect(find.byType(CircularProgressIndicator), findsNothing);
      expect(find.text('notes.pdf'), findsOneWidget);
    });

    testWidgets('changes themes without losing the current selection', (
      tester,
    ) async {
      await mountApp(
        tester,
        () async => FileSelection(files: <ShareFile>[sampleFile()]),
      );
      await tapSelect(tester);
      final scaffold = find.byKey(const ValueKey('main-scaffold'));
      expect(Theme.of(tester.element(scaffold)).brightness, Brightness.light);
      await tester.tap(find.byKey(const ValueKey('theme-toggle')));
      await tester.pumpAndSettle();
      expect(Theme.of(tester.element(scaffold)).brightness, Brightness.dark);
      expect(find.text('notes.pdf'), findsOneWidget);
      await tester.tap(find.byKey(const ValueKey('theme-toggle')));
      await tester.pumpAndSettle();
      expect(Theme.of(tester.element(scaffold)).brightness, Brightness.light);
      expect(find.text('1 file · 1.5 KiB'), findsOneWidget);
    });

    testWidgets('keeps the selection when switching navigation tabs', (
      tester,
    ) async {
      await mountApp(
        tester,
        () async => FileSelection(files: <ShareFile>[sampleFile()]),
      );
      await tapSelect(tester);
      await tapNavigation(tester, 'nav-guide');
      expect(find.text('One step at a time.'), findsOneWidget);
      expect(find.text('Connect nearby'), findsOneWidget);
      await tapNavigation(tester, 'nav-home');
      final count = tester.widget<Text>(
        find.byKey(const ValueKey('selected-count')),
      );
      expect(count.data, '1');
      await tapNavigation(tester, 'nav-files');
      expect(find.text('notes.pdf'), findsOneWidget);
    });

    testWidgets('handles large metadata without reading the file into memory', (
      tester,
    ) async {
      var reads = 0;
      await mountApp(
        tester,
        () async => FileSelection(
          files: <ShareFile>[
            sampleFile(
              name: 'large-video.mkv',
              size: 9663676416,
              openRead: () {
                reads += 1;
                return const Stream<List<int>>.empty();
              },
            ),
          ],
        ),
      );
      await tapSelect(tester);
      expect(find.text('1 file · 9 GiB'), findsOneWidget);
      expect(reads, 0);
    });

    testWidgets('renders narrow screens without layout errors', (tester) async {
      await mountApp(
        tester,
        () async => FileSelection(files: <ShareFile>[sampleFile()]),
        size: const Size(320, 640),
      );
      expect(tester.takeException(), isNull);
      await tapSelect(tester);
      expect(find.text('1 file · 1.5 KiB'), findsOneWidget);
      expect(tester.takeException(), isNull);
      await tapNavigation(tester, 'nav-guide');
      expect(tester.takeException(), isNull);
    });

    testWidgets('supports large system text on a narrow screen', (
      tester,
    ) async {
      tester.binding.platformDispatcher.textScaleFactorTestValue = 2;
      addTearDown(
        tester.binding.platformDispatcher.clearTextScaleFactorTestValue,
      );
      await mountApp(
        tester,
        () async => FileSelection(files: <ShareFile>[sampleFile()]),
        size: const Size(320, 740),
      );
      expect(tester.takeException(), isNull);
      await tapNavigation(tester, 'nav-files');
      expect(tester.takeException(), isNull);
      await tapNavigation(tester, 'nav-guide');
      expect(tester.takeException(), isNull);
    });

    testWidgets('ignores late picker results after the screen is disposed', (
      tester,
    ) async {
      final pending = Completer<FileSelection>();
      await mountApp(tester, () => pending.future);
      final button = find.byKey(const ValueKey('select-files-button'));
      await tester.ensureVisible(button);
      await tester.tap(button);
      await tester.pump();
      await tester.pumpWidget(const SizedBox.shrink());
      pending.complete(FileSelection(files: <ShareFile>[sampleFile()]));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
    });
  });
}
