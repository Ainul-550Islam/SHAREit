# ShareBondhu — sequential file index

## User requirements

1. Every delivered source file must be complete. No omitted implementations or abbreviated code blocks.
2. Preserve existing behavior and public contracts when adding subsequent parts. Return the full updated file, not a patch alone.
3. Continue numbering new authored source/test files sequentially. Existing paths keep their original number.
4. Stop at a useful part boundary and offer `Next Part`.
5. Flutter, Android + iPhone, computer-based development. ShareBondhu is a temporary brand.

## Part 1 — authored source and test files

| Permanent number | Path | Responsibility |
|---|---|---|
| File 1 | `pubspec.yaml` | SDK constraints, pinned direct dependencies, app version |
| File 2 | `lib/main.dart` | App entry, Material app, light/dark theme, picker injection |
| File 3 | `lib/models/share_file.dart` | Lazy-readable file model, typed selection result, size formatting |
| File 4 | `lib/screens/home_screen.dart` | Real system-picker adapter, selection queue, all three tabs and feedback |
| File 5 | `test/widget_test.dart` | 8 model tests and 20 widget tests |

The full Flutter-generated Android/iOS runner, assets and project configuration are included in the source archive. They are scaffolding rather than additional hand-authored Part 1 files. If a later part customizes a previously unnumbered scaffold file, assign it the next new number and show its full content. Documentation and tool-generated lockfiles are listed in the archive inventory separately.

## Existing contracts to preserve

- `ShareBondhuApp` accepts optional `PickShareFiles pickFiles` injection.
- `HomeScreen` requires a picker callback and a theme-toggle callback.
- `pickDeviceFiles()` uses the file_picker 12 static API and produces `FileSelection`. A canceled picker returns an empty selection. Per-file metadata failures do not discard valid selections.
- `ShareFile` takes `name`, `size`, `sourceUri`, and a lazy `readStream` factory. Its `openRead()` method calls the factory only when content is needed.
- File identity is `sourceUri.toString()`, not the filename or a content hash. Some native providers may return a different URI/cache path on a later pick; do not claim content-level deduplication.
- `FileSelection.files` is immutable and carries a non-negative `unavailableCount`.
- Keep validation, file classification and binary-unit formatting.
- Keep additions, removal, clear confirmation, duplicate-reference suppression, picker-cancel preservation, per-file failure feedback, retry, busy-state protection, mounted checks, theme toggling and navigation-state preservation.
- Removing or clearing a selection must not delete the original file or read its content.
- Keep native picker errors visible without leaking raw exception details or source paths.
- Existing keys are used by widget tests. Preserve them or update the full tests with equivalent coverage when UI changes.

## Verified baseline

Date: 2026-09-06.

Toolchain: Flutter 3.47.2 stable, Dart 3.13.2 on Linux.

Dependencies: file_picker 12.2.0, flutter_lints 6.0.0; transitive versions are in pubspec.lock.

`flutter analyze`: no issues.

`flutter test`: 28 passing tests. Native picker results are injected in these tests. Real-device OS integration, Android compilation and iOS compilation are NOT verified.

The UI screenshots were rendered by an internal Flutter widget test with sample metadata; they are not screenshots from a physical phone.

## Current scope and limitations

There are no network endpoints, sockets, sender clients, receiver servers or ads in Part 1. No transfer success or progress is simulated. State is session-only. The file-picker plugin/OS may make temporary copies or fetch cloud-only documents; the app's own selection logic does not eagerly read entire files.

Do not reuse a platform URI as an outgoing remote destination or expose local source URIs to a peer. Transfer code should send sanitized display names and actual streamed bytes. Later parts need explicit receiver approval, authenticated pairing, resource limits, filename/path safety, cleanup on failure and accurate progress.

The first cross-platform transfer target is a shared LAN/hotspot, not iOS Wi-Fi Direct or silent hotspot creation. Check mobile platform network permissions when real networking is introduced. Foreground operation first; do not promise background iOS service availability.

## Next boundary

Part 2 starts with File 6. Add local-network/pairing and transfer foundations in a bounded next group of new files. Integrate UI and platform permissions in the appropriate part. If any current file changes, include its entire updated content and mark it UPDATED with the same permanent file number.

Keep the Part 1 ZIP and `PART_01_FULL_CODE.md` immutable as a readable baseline. Update the working source tree and provide a new versioned archive for each later part. No prior user source was supplied before this baseline.
