# ShareBondhu — Part 1

Flutter দিয়ে নিজের ব্র্যান্ডের Android ও iPhone file-sharing অ্যাপ তৈরির প্রথম ধাপ। এই অংশ একটি চালানো যায় এমন **file-selection foundation**; এখনো কোনো ফাইল পাঠায় বা গ্রহণ করে না।

## এই Part-এ কাজ করে

- নিজস্ব Home / Files / Guide ইন্টারফেস।
- নেটিভ system picker দিয়ে একাধিক ফাইল নির্বাচন।
- ফাইলের নাম, ধরন, সাইজ ও নির্বাচিত ফাইলের মোট সাইজ দেখা।
- একই source URI/reference পুনরাবৃত্তি হলে বাদ দেওয়া। একই নামের ভিন্ন source URI-র ফাইল রাখা হয়। এটি content-hash দিয়ে duplicate detection নয়।
- ফাইলের reference সরানো এবং নিশ্চিত করার পরে পুরো তালিকা পরিষ্কার করা। মূল ফাইল কখনো মুছে ফেলা হয় না।
- Picker cancellation, unavailable files, permission errors ও repeated taps সামলানো।
- Light/dark theme; তালিকা ও theme choice শুধু চলতি session-এ থাকে।
- ২৮টি model/widget test।

## চালু করুন

এই প্রজেক্ট Flutter **3.47.2** এবং Dart **3.13.2** দিয়ে static analysis ও automated test করা হয়েছে। `pubspec.yaml`-এর সর্বনিম্ন সংস্করণ Flutter 3.47.0 / Dart 3.13.0। `file_picker` 12.2.0 এবং `flutter_lints` 6.0.0 pin করা আছে; `pubspec.lock` রাখা হয়েছে।

Flutter install: https://docs.flutter.dev/install

Android Studio: https://developer.android.com/studio

ZIP খুলে `sharebondhu` ফোল্ডারে terminal খুলুন। Flutter SDK PATH-এ থাকতে হবে।

```bash
flutter --version
flutter doctor -v
flutter pub get
flutter analyze
flutter test
flutter devices
flutter run
```

Android: Android Studio-এর SDK/toolchain প্রস্তুত করুন। নিজের Android ফোনে Developer options ও USB debugging চালু করে কম্পিউটারের debugging অনুমতি দিন, অথবা Android emulator চালান। এই runner-এর জন্য Java 17 বা নতুন compatible JDK দরকার; Java 11 ব্যবহার করবেন না। Android Studio-এর bundled JDK ব্যবহার করা সবচেয়ে সহজ। একাধিক device থাকলে `flutter run`-এর তালিকা থেকে Android device বেছে নিন।

নিজের কম্পিউটারে debug APK তৈরি করতে:

```bash
flutter build apk --debug
```

Output: `build/app/outputs/flutter-apk/app-debug.apk`। এটি development APK, store-ready release নয়। এই বিতরণে কোনো তৈরি APK/IPA নেই।

iPhone: iOS build-এর জন্য Mac, compatible Xcode এবং তার toolchain দরকার। Mac-এ Simulator চালাতে:

```bash
open -a Simulator
flutter devices
flutter run
```

বাস্তব iPhone-এ চালাতে Xcode-এ নিজের signing team সেট করতে হবে। এই generated iOS project-এর deployment target 15.0। Windows/Linux থেকে স্থানীয়ভাবে iOS binary build হবে না।

## সম্পূর্ণ কোড ও ফাইল তালিকা

- `docs/PART_01_FULL_CODE.md`: File 1–5-এর শুরু থেকে শেষ পর্যন্ত সম্পূর্ণ কোড এবং বাংলা নির্দেশনা।
- `docs/FILE_INDEX.md`: স্থায়ী file number ও পরের Part-এ আগের logic রক্ষার নোট।
- `docs/FILE_INVENTORY.txt`: ZIP-এর সব ফাইলের পথ।
- `docs/TEST_RESULTS.txt`: এই পরিবেশের analysis ও test output।
- `docs/part01-preview.png`: Flutter test renderer থেকে UI preview; নির্বাচিত ফাইলগুলো শুধু পরীক্ষার sample metadata।

পাঁচটি নিজস্ব source/test ফাইলের পাশাপাশি ZIP-এ standard Android/iOS runner, configuration, launcher assets, Gradle wrapper ও lockfile আছে। Flutter SDK, package caches, compiled build output এবং machine-specific generated configuration বিতরণে রাখা হয়নি। `flutter pub get` ও `flutter run` প্রয়োজনমতো সেগুলো তৈরি করবে।

## কী এখনো হয়নি

- Local-network discovery, pairing, real sending/receiving, receiver approval, byte progress ও cancellation।
- Received-file storage, transfer history ও background transfer।
- Final launcher icon/name configuration, production signing, store privacy/compliance এবং বিজ্ঞাপন।
- Physical Android/iPhone-এ native file-picker verification বা APK/IPA compilation। এখানে automated tests-এ picker result inject করা হয়েছে; আসল OS picker চালানো হয়নি।

এই Part-এর UI ইংরেজি; গাইড বাংলায়। বাংলা UI পরে যোগ করা যাবে। প্রথম transfer সংস্করণের লক্ষ্য একই Wi-Fi বা device-to-device traffic অনুমোদন করে এমন hotspot। Android-এর Wi-Fi Direct API iPhone-এ একইভাবে পাওয়া যায় না; automatic hotspot setup প্রতিশ্রুত নয়।

ShareBondhu নাম ও `com.sharebondhu.sharebondhu` application ID অস্থায়ী। প্রকাশের আগে brand availability, নিজের unique application ID, launcher branding ও release signing ঠিক করতে হবে। Android release template বর্তমানে debug signing ব্যবহার করে; সেটি প্রকাশ করবেন না।

## Next

চ্যাটে **Next Part 2** লিখুন। পরের ধাপে নতুন File 6–10 শুরু হবে; আগের ফাইল বদলালে একই file number-এ সম্পূর্ণ আপডেটেড ফাইল দেওয়া হবে।
