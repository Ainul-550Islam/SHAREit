# ShareBondhu — permanent file index after Part 6

## Baseline and delivery rules

Part 6 extends ShareBondhu_Part_05.zip (0.5.0+5), SHA-256 `5dee15caa9c3c0aed067c074dfa15937577c38af6eeee6866144bad87ae0611c`. All 127 entries matched the initial working project. Keep earlier versioned ZIPs/full-code guides immutable.

Provide full files, not shortened implementations or patches. Keep existing functions/classes/endpoints/validators/permissions/tests. New files retain sequential permanent numbers. Reuse the single ShareCoin domain/service; do not create another wallet or fake real-money behavior.

## Permanent numbers

| File | Path | Part 6 |
|---|---|---|
| 1 | `pubspec.yaml` | UPDATED — 0.6.0+6, exact url_launcher 6.3.2 |
| 2 | `lib/main.dart` | Retained |
| 3 | `lib/models/share_file.dart` | Retained |
| 4 | `lib/screens/home_screen.dart` | Retained |
| 5 | `test/widget_test.dart` | Retained — 97 tests |
| 6 | `lib/models/transfer_models.dart` | Retained |
| 7 | `lib/services/local_transfer_service.dart` | Retained |
| 8 | `lib/screens/nearby_screen.dart` | Retained |
| 9 | `android/app/src/main/AndroidManifest.xml` | Retained |
| 10 | `ios/Runner/Info.plist` | Retained |
| 11 | `lib/models/saved_transfer.dart` | Retained |
| 12 | `lib/services/transfer_history_service.dart` | Retained |
| 13 | `lib/screens/history_screen.dart` | Retained |
| 14 | `lib/widgets/pairing_qr_card.dart` | Retained |
| 15 | `lib/screens/scan_pairing_screen.dart` | Retained |
| 16 | `lib/models/transfer_activity.dart` | Retained |
| 17 | `lib/services/transfer_progress_controller.dart` | Retained |
| 18 | `lib/widgets/transfer_progress_panel.dart` | Retained |
| 19 | `lib/widgets/transfer_result_panel.dart` | Retained |
| 20 | `test/transfer_progress_test.dart` | Retained — 107 tests |
| 21 | `lib/models/share_coin_models.dart` | Retained — original Offer/wallet/policy models |
| 22 | `lib/models/user_models.dart` | Retained |
| 23 | `lib/services/share_coin_service.dart` | UPDATED — optional reward capability, additive query/config options |
| 24 | `lib/services/connectivity_service.dart` | Retained |
| 25 | `lib/screens/share_coin_home_screen.dart` | UPDATED — new routes, old views/actions preserved |
| 26 | `lib/models/offerwall_models.dart` | NEW — filters/view state, reward sessions, launch grants |
| 27 | `lib/services/offerwall_service.dart` | NEW — pagination/starting/status, resource policy/cache, paged feeds |
| 28 | `lib/screens/offerwall_screen.dart` | NEW — Offerwall/details/consent/lazy thumbnails |
| 29 | `lib/screens/reward_center_screen.dart` | NEW — provider-ad coordinator, daily/promo, paged ledger/history UI |
| 30 | `test/offerwall_rewards_test.dart` | NEW — 54 tests and test-only catalog/provider fixtures |

pubspec.lock and the generated Android/iOS plugin registrants changed for url_launcher. No manual permission, target SDK, application ID, ATS or runner configuration changes were made. Regenerate native plugin glue with Flutter tools; do not number generated files as new authored features.

## Verification

2026-09-09; Flutter 3.47.2 / Dart 3.13.2, Linux. Static analysis is clean. **258 tests passed: all 204 previous tests, plus 54 Part 6 tests.** Both previous test files are byte-identical. Original transfer models/services/screens/widgets and platform permissions are byte-identical. Existing classes/enums/functions in Files 23 and 25 were retained.

New tests include 300-offer creation/pagination/scrolling/filter/search/sort, 1,020-offer bounded-window traversal, duplicate IDs/starts, expiry/consent, receipt/ledger linkage, provider callback races, cooldown/limits, daily/promotion behavior, signature-error mapping, withdrawal/referral regression, cache/image bounds, offline/account/disposal and navigation checks.

Reward/provider behavior uses a test backend and test ad adapter; it does not prove real attribution/signatures, advertiser payouts or native ad playback. No native production build, real phones/camera, two-phone Wi-Fi, OS store launch, payout provider or store verification is claimed.

## Existing contracts retained

- One main app and first-class file-sharing home; no Offerwall-only replacement. Preserve original picker/selection/theme/routes and ShareCoinFileAction integration.
- Keep SB1 QR/manual pairing, explicit sender action and receiver approval, all five v1 endpoints, TLS pins/tokens/local-native restrictions and no plaintext/redirect/certificate-bypass workaround.
- Keep 50-file/2 GiB-per-file/4 GiB-batch limits, invitation/approval/idle/batch deadlines, owned stream cancellation, exact byte/hash validation, atomic commit/receipt/recovery and honest cancellation ambiguity.
- Keep Part 4 real progress counters, attempt/epoch/sequence guards, rate-only timers, receipt-only completion and safe settled retry.
- Keep read-only received history, app-owned canonical paths, symlink checks, explicit SHA-256, export/iPad anchor and distinct selectable-text PageStorageKeys.
- Keep native permissions and foreground/camera/disposal/startup guards. Rewards connectivity never gates the local transfer engine.
- Keep Files 21–23 as the one wallet/event/user service domain. Integer coin/minor-unit arithmetic, account-scoped cache, idempotency, fresh financial checks, wallet invalidation and withdrawal status-by-key stay authoritative only through the backend.
- Default auth/backend/ad/payout integration remains unconfigured. Never treat a client click, install, callback or device date as proof of earning, and never locally adjust a balance as payout authority.

## Part 6 contracts

- Reuse Offer/OfferStatus/OfferQuery/PageInfo/CoinPage from File 21. File 26 adds projections/filters and server-session/grant types, not a replacement catalog/wallet model.
- Preserve the original ShareCoinOperation enum. ShareCoinRewardBackend is an optional capability on the same instance/scope, with transaction/prepareReward/sessionStatus/offerLaunch extension operations. See PART_06_BACKEND_CONTRACT.md.
- Original default request payloads remain; minimum/maximum reward filters are sent only when supplied. Fresh ad/daily configuration can opt out of cache.
- Catalog page size defaults to 20; UI window defaults to 500 with subsequent-window traversal. Backend totals can exceed 300/1,000. Maintain lazy slivers, bounded recent IDs/cursors, duplicate notices and stale query/account/disposal rejection.
- Search is debounced; backend filters/sorts paginated results. Do not seed the app with the 300-offer test catalog. Catalog country/platform hints remain untrusted; backend policy must authorize eligibility.
- Offer start uses the old idempotent start API, then a scoped server-issued OfferLaunchGrant. Grant user/start/offer/platform/TTL and trusted origin are checked, including expiry after user consent. Open/install is not completion.
- Link/image origins are exact operator-configured HTTPS allowlists; defaults deny. No wildcard trust, raw credential headers or unreviewed provider URL launch. External browser redirects still require trusted-provider/back-end review.
- Thumbnail fetch/decode/concurrency/queue/cache/dimensions are bounded; normalize static raster images and evict decoded MemoryImages on tile disposal. Do not eagerly fetch hundreds of full-size images.
- RewardedAdAdapter must wrap a real compliant SDK. Default UnavailableRewardedAdAdapter never simulates an ad. Completion events carry the matching session/provider event, not a local coin amount.
- Fresh backend RewardSession controls source/provider/target/amount/expiry/cooldown/quota. requestKey and event idempotency keys have separate roles. Daily claims use server-issued references and reviewed server policy values.
- Only one active/pending coordinator action is handled at a time. Duplicate/stale/premature callbacks cannot submit another event. Interruption does not imply the provider/backend failed; reconcile by IDs.
- Approved events and completed offers need a fresh matching completed credit transaction. Display its actual amount, not the catalog promise. Rejected/reversed/pending ledger records are not approved credits. Refresh the same wallet; never increment locally.
- Promotion clicks create tracking and launch only, not a RewardEvent credit. Backend attribution decides completion. Referral and withdrawal form behavior remain available; new transaction/withdrawal feeds paginate and retain negative outcomes.
- Old File 25 methods remain accessible via configuration/info actions. New routes refresh the wallet on return and retain navigation to all original file-sharing actions.

## Next

Next new files are **Part 7 — File 31–35**. No Part 7 code is implemented. Actual backend/auth/provider/ad SDK/payout integration, trusted origins/configuration, incentive-policy review and native/device/store verification remain outstanding. Obtain the next objective and preserve this tested baseline.
