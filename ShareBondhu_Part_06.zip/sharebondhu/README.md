# ShareBondhu — Part 6 (File 26–30)

Version **0.6.0+6**, built on the complete Part 5 project. Adds a scalable Offerwall, provider-link consent, reward coordination, daily claim flow, promotions and paginated ledger/withdrawal views while retaining the one ShareCoin service and the original sharing app.

**Production defaults are still unconfigured.** No real catalog, login backend, rewarded-ad SDK, provider attribution or payout service is bundled. The 300-offer catalog and provider completion events in tests/previews are test-only. Client actions never locally credit or debit real money.

## Added files

| File | Path |
|---|---|
| 26 | `lib/models/offerwall_models.dart` |
| 27 | `lib/services/offerwall_service.dart` |
| 28 | `lib/screens/offerwall_screen.dart` |
| 29 | `lib/screens/reward_center_screen.dart` |
| 30 | `test/offerwall_rewards_test.dart` |

File 26 reuses the existing Offer/OfferStatus/OfferQuery/CoinPage models from File 21; it does not create a second offer or wallet domain. It adds filter/view state, server-issued reward sessions and scoped offer-launch grants.

File 27 connects the existing ShareCoinService to pagination/search/filter/starting/status UI and bounded thumbnail loading. File 28 renders lazy offer cards, featured entries, filters and complete offer details with tracking consent. File 29 coordinates a real provider-ad adapter, backend daily/promotion sessions, verified ledger credit and paginated records. Its default ad adapter is explicitly unavailable, not simulated playback.

## Updated files and dependencies

- **File 1 — pubspec.yaml:** version 0.6.0+6 and exact `url_launcher: 6.3.2`.
- **File 23 — share_coin_service.dart:** additive optional reward-backend capability, reward-range arguments and fresh configuration options. Existing methods and ShareCoinOperation enum remain.
- **File 25 — share_coin_home_screen.dart:** new feature routes; old configuration/catalog/history methods remain accessible through the information actions. Existing referral and guarded withdrawal UI remain.
- `pubspec.lock` and generated Android/iOS plugin registrants updated by Flutter for url_launcher. Existing platform permission/runner configuration is unchanged.

url_launcher is used only for explicit allowlisted HTTPS destinations after a backend start/grant and user consent. It is not an ad SDK or attribution verifier. Full stop/rebuild is required for the new native plugin; hot reload alone is not enough.

## Implemented behavior

### Offerwall

- Backend pagination, search debounce, category, minimum/maximum reward and sort controls.
- All ten existing categories are supported; country/platform availability remains server-controlled.
- Lazy sliver rendering, a small featured strip, loading/error/empty/cached states and pull-to-refresh.
- Default 20 records/page, at most 500 records in the current UI window, and explicit next-window traversal. Backend totals are not capped at 300; a 1,020-offer fixture is tested too.
- Duplicate IDs are removed across loaded pages with a notice; recent cursor cycles, stale query/account callbacks, malformed responses and disposed work are rejected.
- Starting obtains fresh backend offer state, then the existing idempotent start and a scoped launch grant. No install/package-existence heuristic is used as completion proof.
- User reviews requirements/terms and tracking consent before a provider link opens. Reopening a recorded start does not create another start. An expired grant is rechecked after consent.
- A nominal offer reward is not displayed as credited. Completed +amount requires a fresh, matching completed backend credit transaction. Rejected/reversed results are not disguised as approved rewards.

### Resources

Trusted link/image origins must be configured by the app operator; defaults deny external resources. HTTPS-only exact origins, no userinfo/IP-host/nonstandard-port URLs, no image redirects or authentication headers. Images are bounded to 512 KiB download, static raster data, at most 2048×2048/4 Mi pixels, normalized to at most 128×128, and stored in a 40-entry/4 MiB cache by default. At most 3 loads run concurrently, with a bounded queue. Disposed image widgets evict decoded MemoryImage entries.

External browsers/store apps may follow provider redirects after launch; the operator/backend must approve the provider and its redirect/attribution chain. The client can restrict the initial launch, not independently audit every external browser redirect.

### Rewards

- Ad loading/ready/showing/completed/skipped/failed, tracking, pending, ledger-check, approved, cooldown, daily-limit, rejected/reversed and interrupted states.
- A configured provider adapter plus a fresh backend eligibility session is required. No provider/ad IDs or SDK are invented.
- Provider completion is a claim submitted through the existing RewardEvent service. Duplicate/stale callbacks cannot produce another submission. Completion before presentation is ignored.
- Backend approval must resolve to a matching completed credit transaction before approval is shown. Wallet data is refreshed from the backend, never incremented locally.
- Daily rewards use fresh server policy and a server-issued daily reference. Device date does not decide eligibility.
- Promotion opens create tracking only; no reward event is submitted for the click. Provider/backend status determines later credit.
- Cooldown is estimated from backend time plus monotonic elapsed time. Reaching zero prompts a new backend eligibility check; it does not grant a reward or reset a daily limit.
- Existing referral summary/copy flow and withdrawal validation/form/status-by-key remain. Transactions and withdrawal history now have lazy pagination/windows and retain rejected/reversed/cancelled records.

## Backend contract

`docs/PART_06_BACKEND_CONTRACT.md` documents the optional ShareCoinRewardBackend capability on the **same authenticated backend**, launch grants, sessions, transaction verification and provider requirements. Existing backend operations still work without that capability; new reward/launch operations honestly report missing setup until it is implemented.

No real endpoint is hard-coded. A production gateway must authenticate each request, enforce idempotency/authorization/amount/country rules, verify provider signatures/attribution, implement atomic ledger/payout processing and return consistent scoped data. The client is not an anti-fraud boundary.

## Automated verification

Actually run with Flutter **3.47.2 / Dart 3.13.2**, Linux:

- `flutter analyze --no-pub`: **No issues found**.
- `flutter test --no-pub --reporter expanded`: **258 tests passed**.
- Retained baseline: **204 tests**, byte-identical test files.
- Added File 30: **54 tests**.

Tests cover 300 offers, 1,020-offer window traversal, pagination/filter/search/sort/expiry, duplicate IDs/starts/ad callbacks, pending versus credited rewards, backend signature-error mapping, cooldown/limits, daily/promotion flow, withdrawal regression, stale/account/lifecycle guards, consent expiry, bounded images, lazy scrolling and sharing navigation. Ad/provider tests use explicit test adapters/backend fixtures, not real providers. Earlier TLS tests remain actual same-computer loopback transfers.

## Commands

```bash
flutter pub get
flutter analyze
flutter test
flutter run
```

Stop and rebuild the app for url_launcher. Android requires the existing compatible Android SDK/JDK toolchain; iPhone builds require Mac/Xcode/signing. The original transfer permissions, 50-file/2 GiB-per-file/4 GiB-batch limits, 10-minute invitation and 60-second receiver-approval timeout remain.

## Manual/device verification — not performed here

1. On Android, check that Home still exposes Send/Receive, QR/manual pairing, saved files/history and theme. Open ShareCoin → Offers and return without losing selection.
2. Default build: confirm unavailable/setup states, no seeded 300-offer production catalog, no fake balance and no simulated paid ads.
3. With an authenticated staging backend, return at least 300 lightweight offers. Scroll to the end; search, filter, sort, refresh, test cached/offline pages and images that fail. Exercise a catalog larger than 500 through next windows.
4. Read an offer's requirements/terms, accept tracking consent, confirm the allowlisted domain and open a development provider link. Decline consent once. Verify start/open/install alone never produces credit. Return and refresh backend status/transaction.
5. With a compliant native ad adapter using development units, test load, ready, showing, completion, skip, failure, duplicate callbacks, interruptions, cooldown/daily limits and pending/approved/rejected/reversed backend outcomes. Confirm the backend verifies evidence and client balance changes only after a wallet response.
6. Test promotion tracking without click credit; daily policy and stale sessions without manipulating device-date eligibility. Check referral qualification and transaction reversal visibility.
7. With staging payout configuration only, test minimum/balance/conflicts, stable request keys, lost confirmation and status reconciliation. Do not interpret staging records as real payouts.
8. Test local Wi-Fi without reward internet access. On two real phones, test existing TLS file sharing, approval, progress/cancel/retry, final receipt, history and SHA-256. Rewards must not gate that flow.
9. Repeat applicable tests on a real iPhone: HTTPS store links, app-background transitions, existing camera/local-network permissions and native share flow. Do not assume emulator/widget success proves this.

## Known limitations

No real authentication backend, ad SDK/provider, live advertiser inventory/attribution or payout provider is connected by default. The extension is a client contract, not a deployed server. Native store launch, production builds, two-phone/camera behavior, real provider signatures, payouts and store compliance have not been verified here.

Client caches, activity and duplicate guards are bounded/in-memory. Server uniqueness, financial consistency, risk scoring, rate limits, country eligibility, referral validation, audit/reconciliation and incentive-policy compliance remain required. Interrupted provider activity may be completed only on the backend and needs status/history refresh. External redirect chains require trusted-provider review. Existing foreground/private-IPv4/no-resume transfer limitations are unchanged.

# ▶ Next — Part 7 (File 31–35)
