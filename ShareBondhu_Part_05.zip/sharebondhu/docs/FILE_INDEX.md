# ShareBondhu — permanent file index after Part 5

## Authoritative baseline and delivery rules

Part 5 was built on `/home/user/ShareBondhu_Part_04.zip`, version 0.4.0+4. No separately named new upload was visible; the available ZIP matches the user's stated baseline. All 113 archive entries were read/inventoried and matched the starting working copy. Preserve the versioned archives and full-code guides as immutable history.

Provide complete files, no shortened implementations or patch-only deliverables. Retain previous functions/classes/endpoints/validators/permissions/tests. New authored files have permanent sequential numbers; updating a file retains its number. This part adds the first ShareCoin foundation, not a competing wallet and not a real connected payout system.

## Permanent numbering

| File | Path | Part 5 |
|---|---|---|
| 1 | `pubspec.yaml` | UPDATED — version 0.5.0+5 only |
| 2 | `lib/main.dart` | Retained |
| 3 | `lib/models/share_file.dart` | Retained |
| 4 | `lib/screens/home_screen.dart` | UPDATED — additive ShareCoin route/toolbar entry |
| 5 | `test/widget_test.dart` | Retained — all 97 original tests |
| 6 | `lib/models/transfer_models.dart` | Retained |
| 7 | `lib/services/local_transfer_service.dart` | Retained |
| 8 | `lib/screens/nearby_screen.dart` | Retained |
| 9 | `android/app/src/main/AndroidManifest.xml` | Retained |
| 10 | `ios/Runner/Info.plist` | Retained |
| 11 | `lib/models/saved_transfer.dart` | Retained |
| 12 | `lib/services/transfer_history_service.dart` | Retained |
| 13 | `lib/screens/history_screen.dart` | Retained |
| 14 | `lib/widgets/pairing_qr_card.dart` | Retained |
| 15 | `lib/screens/scan_pairing_screen.dart` | Retained |
| 16 | `lib/models/transfer_activity.dart` | Retained |
| 17 | `lib/services/transfer_progress_controller.dart` | Retained |
| 18 | `lib/widgets/transfer_progress_panel.dart` | Retained |
| 19 | `lib/widgets/transfer_result_panel.dart` | Retained |
| 20 | `test/transfer_progress_test.dart` | UPDATED — original 46 tests plus 61 Part 5 tests |
| 21 | `lib/models/share_coin_models.dart` | NEW — economy/catalog/policy DTOs and validators |
| 22 | `lib/models/user_models.dart` | NEW — credential-free identity/account/referral DTOs |
| 23 | `lib/services/share_coin_service.dart` | NEW — gateway contract, unavailable default, cache/idempotency/financial guards |
| 24 | `lib/services/connectivity_service.dart` | NEW — separate internet/local/backend states and bounded probes |
| 25 | `lib/screens/share_coin_home_screen.dart` | NEW — dashboard, foundation views, guarded withdrawal request/status UI |

Do not assign File 26 to a Part 5 test: new tests were appended to existing File 20, preserving its previous test bodies exactly. Standard scaffold/assets/lockfiles/docs are also delivered in the archive inventory.

## Verification

Date: 2026-09-08. Flutter 3.47.2 / Dart 3.13.2 on Linux. Current version 0.5.0+5.

Actually run: flutter analyze --no-pub (No issues found), flutter test --no-pub --reporter expanded (204 passing tests). This is 143 retained baseline tests plus 61 new model/service/connectivity/UI/regression tests. The new backend fixtures are test-only; no real authentication, provider attribution, advertiser reward or payout is verified.

All baseline source/native files except Files 1, 4 and 20 remain byte-identical. Original File 20 test bodies were compared after removing only the added imports/registration/suffix and match exactly. No dependency was added; pubspec.lock and Android/iOS configuration are unchanged.

No native Android/iPhone, camera, two-phone Wi-Fi, production build/signing or store test is claimed. Preview images are Flutter test rendering with an unconfigured backend and controlled network status, not device screenshots or real funds.

## Existing file-sharing contracts

- One ShareBondhuApp entry point/theme owner; original Home/Files/Guide tabs, picker and immutable selection semantics remain. ShareCoin is a new route, not a replacement home.
- Keep source-URI identity/deduplication, lazy readStream/openRead, valid partial selections, clear confirmation, busy/mounted guards and no original-file deletion.
- Keep SB1 manual and QR pairing. Scanning fills a code only. Sender asks to send; receiver explicitly approves. Reject arbitrary scanned URLs.
- Preserve fresh certificate identities, exact TLS pin/host/port, native-local checks, separate tokens, all five v1 endpoints and wire fields. No cleartext fallback, proxy/redirect bypass or secret logging.
- Preserve 50-file, 2 GiB/file, 4 GiB/batch, 10-minute invitation and 60-second receiver-approval limits and other existing deadlines.
- Keep exact byte lengths, streamed SHA-256, per-file staging, final atomic commit/receipt, cancellation cleanup and uncertain-outcome handling. Cancel the owned iterator before hash disposal.
- Keep Part 4 local telemetry, attempt IDs/epochs/sequences, real counters, rate-only timers, receipt-only completion and safe settled retry. Never infer delivery from 100% bytes.
- Keep foreground/camera/startup/disposal protection and all native permissions. No rewards connectivity flag may disable the original nearby actions.
- Received history remains read-only in Documents/ShareBondhu/Received. Preserve safe canonical paths, link checks, bounded receipts/scans, folder identity, explicit checksum recheck, native export and iPad anchor.
- Preserve distinct PageStorageKeys for selectable checksum text inside expandable history tiles.

## ShareCoin foundation contracts

- There is one economy domain/service: Files 21–23. Do not invent a second wallet in Part 6.
- Default backend is explicitly unconfigured: no hard-coded remote host, fake balance, local account, ad SDK, production ad IDs, attribution integration or payout provider.
- Coin amounts and minor currency units are bounded whole JSON integers. Use BigInt intermediates for rational conversion; do not introduce floating-point financial math or a local balance increment/decrement as authority.
- AccountScope is a non-secret correlation reference, not authentication. Real adapters own secure auth and must validate server identity. Account/session changes clear cached/pending client state and reject stale replies.
- RewardEvent is an untrusted claim. Only created claims may be submitted; approved responses refer to a backend transaction. Provider action/event/key deduplication is bounded client protection, not a replacement for server uniqueness/signature/attribution checks.
- No offline money queue. Cached reads are explicitly labelled; fresh-only checks do not share cache-permitted requests. Wallet generations reject stale replies across a mutation. Mutations invalidate the wallet, never edit coin amounts.
- Withdrawals require fresh account/wallet/policy, minimum/balance/conflict checks, enabled saved destination, unchanged fee/rate/policy and idempotency. Unknown results retain their key and can be checked by key without reposting. Backend balance reservations and payout remain authoritative.
- Payout DTOs store masked destination text/opaque references, not raw credentials. bKash/Nagad/Rocket/PayPal/Bank are configuration choices only.
- Page/query DTOs support totals larger than 300, page size up to 100, cursors, explicit hasNext and bounded unique page items. Part 5 dashboard catalogs are small previews; Part 6 may add full lazy pagination/search/filter UI using these types.
- DTO URLs are HTTPS-only data in this part, not launched or image-fetched resources. Future provider image/link handling must enforce trusted origins/redirect policy and user consent.
- Ads/daily/referral configurations are server-provided data. No watched ad, installation, device date or multiple locally created accounts can locally award coins.
- Connectivity reports internet, private IPv4 candidate and backend health independently. No arbitrary public ping endpoint is configured. Coalesce checks, bound timeouts, ignore stale/disposed results and avoid reconnect loops.
- ShareCoinHomeScreen returns ShareCoinFileAction to HomeScreen, which uses the existing picker/send/receive/history methods. Do not remove those shortcuts or underlying routes.

Read PART_05_BACKEND_CONTRACT.md before adding providers or a server adapter. It documents actual operation/envelope/model contracts, cache/idempotency bounds, transport/error expectations and required server anti-fraud/financial enforcement.

## Next

Next is **Part 6 — File 26–30**. Do not claim Part 6's 300-offer Offerwall, real ad playback, real login or cash integrations as already implemented. Reuse this foundation, preserve all 204 tests and source contracts, and continue providing full updated files.
