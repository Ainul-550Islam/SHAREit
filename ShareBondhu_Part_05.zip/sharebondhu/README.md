# ShareBondhu — Part 5 (File 21–25)

Version **0.5.0+5**. Adds the missing ShareCoin/account/service foundation on the authoritative `ShareBondhu_Part_04.zip` baseline. The file-sharing app stays the primary home and has a new ShareCoin toolbar entry.

**This build does not contain a connected rewards backend, authentication provider, ad SDK, offer-attribution integration or payout provider. The default dashboard shows Wallet unavailable / Account setup required, not a fake balance.**

## What was inspected

The available Part 4 ZIP was read and inventoried: all 113 entries matched the working project before changes. Dart types/functions, all existing tests, pubspec/lockfile, Android/iOS configuration, and Part 1–4 contracts were reviewed. The source had TLS/manual/QR sharing, approval, progress/results, SHA-256, history, export and lifecycle handling; no wallet/account/reward/withdrawal foundation existed.

The original 143-test baseline is retained. `docs/PART_05_BASELINE_AUDIT.json` records the archive/file hashes. This was the matching workspace ZIP; no separate newly named upload was visible.

## Files added

| File | Complete source path |
|---|---|
| 21 | `lib/models/share_coin_models.dart` |
| 22 | `lib/models/user_models.dart` |
| 23 | `lib/services/share_coin_service.dart` |
| 24 | `lib/services/connectivity_service.dart` |
| 25 | `lib/screens/share_coin_home_screen.dart` |

## Files updated

- **File 1 — pubspec.yaml:** version only, to 0.5.0+5.
- **File 4 — home_screen.dart:** additional ShareCoin route/toolbar action and returns to existing send/receive/history functions. All prior home functions, tabs, keys and behavior remain.
- **File 20 — transfer_progress_test.dart:** imports, one registration call, and appended Part 5 fixtures/tests. Original Part 4 test bodies are retained exactly.
- Current documentation, index, inventory and reports are updated. Historical versioned archives/full-code guides remain unchanged.

All other existing Dart source/test files, the dependency lockfile and Android/iOS files remain byte-identical to the Part 4 ZIP. No TLS engine, pairing model, transfer callback, checksum rule, received-history implementation or permission was replaced.

## Dependencies added

**None.** Existing exact package versions remain. No ad/auth/connectivity SDK was added. The local connectivity probe reuses the existing `localIpv4Addresses()` helper; internet/backend probes are explicitly injectable.

Verified toolchain: Flutter **3.47.2**, Dart **3.13.2**. Minimums remain Flutter 3.47.0 / Dart 3.13.0. Android uses the existing generated target/compile SDK 36 and minimum SDK 24. iOS deployment target remains 15.0. Android needs a compatible JDK 17+ and Android SDK; iPhone builds require Mac/Xcode/signing.

## Implemented foundation

- Immutable validated wallet, transaction, reward, rational currency conversion, withdrawal policy/intent/status, payout method, ad configuration, promotion, offer, query/page, offer-start and daily-policy models.
- User/account/referral models, account states and future authentication-method metadata. There is no password/token storage or fabricated sign-in flow.
- JSON serialization, strict enum/ID/UTC date validation, bounded text/collections, nonnegative whole-number coin amounts and exact BigInt intermediate payout arithmetic.
- A ShareCoinBackend interface and an explicitly unconfigured production default. No remote host is hard-coded or falsely described as working.
- Account-scoped memory cache with explicit cache/server labels, fresh-only financial checks, stale-response guards, bounded in-flight/idempotency bookkeeping and safe error mapping.
- Reward/provider-action duplicate guards; withdrawals validate current account/balance/minimum/policy/fee/destination/conflicts before a request. Unknown outcomes retain their original key and can be queried by key without another submission.
- No local wallet additions/subtractions, offline reward queue or fake payouts. Mutation responses invalidate the wallet so it must be refreshed from the backend.
- Separate internet, private IPv4 interface and backend states; bounded coalesced probes, stale-generation/disposal protection and no reconnect loop.
- A ShareCoin dashboard with wallet/setup state, Earn entries, transaction/withdrawal views, file-sharing shortcuts and status. Unconfigured operations explain the missing integration.
- Connected test/real adapters can supply read-only catalog/configuration/history views. Offers/promotions are bounded previews; no store URL is launched and no provider images are fetched in this part.

## ShareCoin architecture

**User action → provider/tracking event → RewardEvent claim → backend validation → transaction → wallet refresh.**

Started offers, watched-ad client callbacks, promotion opens, device dates and locally created accounts are not proof of rewards. An approved event references a backend transaction; the client does not add its requested amount to the displayed balance.

## Withdrawal architecture

**Backend wallet/policy → request with stable idempotency key → server validation/reservation → admin/provider processing → paid/rejected status → wallet refresh.**

bKash, Nagad, Rocket, PayPal and Bank are configuration choices only. The client submits an opaque saved destination reference, not payment credentials. A request response is not a payout. After an uncertain response, the form can check the original key; it does not silently retry or subtract funds locally.

## Backend and anti-fraud requirements

See `docs/PART_05_BACKEND_CONTRACT.md` for the operation/envelope/schema contract. A real authenticated HTTPS adapter, server account/wallet/transaction store, provider evidence verification, payout integration and admin/risk controls are still required.

Enforce authentication/authorization, event uniqueness, payload-bound idempotency, amount/campaign calculation, limits, server-time eligibility, referral qualification, provider signature/attribution verification, atomic balances/reservations, conflicting-withdrawal prevention, reconciliation, reversals and audit logs on the server. Client guards cannot secure real money against modified apps, account farms or multiple devices. Review provider incentive/redemption rules and applicable legal/privacy obligations before production.

## Offline behavior

- No account/backend: explicit setup/unavailable state; no default coin balance.
- Wallet unavailable: a validated same-account memory cache may be displayed, clearly marked cached. Otherwise show unknown/unavailable.
- Reward submission offline: reject safely; do not queue local credits.
- Offer reads offline: return only explicitly marked cached data when allowed.
- Withdrawal offline: disable submission; no fake local deduction.
- Private network without internet: existing nearby sharing remains available where its original routing/pairing implementation permits it.

Internet is **unknown by default**, because no arbitrary third-party ping endpoint is introduced. A configured backend health probe is independent of a general internet probe. A private IPv4 interface is a candidate, not proof of Wi-Fi type or peer reachability.

## Automated verification

Actually run on Linux:

- `flutter analyze --no-pub`: **No issues found**.
- `flutter test --no-pub --reporter expanded`: **204 tests passed**.
- Previous baseline: **143 tests retained**. New Part 5 tests: **61**.

Tests include validation/serialization, overflow, idempotency, pending/uncertain rewards and withdrawals, account switching, stale wallet replies, cache labels, local-vs-internet status, lifecycle/disposal, dashboard navigation and existing transfer regressions. Reward/backend tests use **TestShareCoinBackend**, confined to the test file. It is not a production backend or evidence of real funds.

No real Android/iPhone, camera, two-phone LAN, ad provider, advertiser attribution, payout, APK/IPA, signing or store verification was performed here.

## Verification commands

```bash
flutter pub get
flutter analyze
flutter test
flutter run
```

Use a hot restart after updating these Dart classes. No new native full rebuild is required solely for Part 5 because no native plugin or permission changed. If earlier Part 3 plugins were not built into the installed app, rebuild those before using their features.

## Manual verification — required, not performed here

1. Run on Android. Confirm the existing home still exposes file selection, Receive files, Saved files, tabs and theme toggle. Open ShareCoin from its toolbar icon.
2. With the production default, confirm Wallet unavailable / Account setup required and no fabricated balance, login or payout.
3. Open Watch Ads, Offers, Promotions, Daily Reward, Referral, Transactions and Withdraw. Unconfigured actions must explain the requirement rather than credit money.
4. Test airplane/offline conditions and a private Wi-Fi/hotspot without internet. Coin status should be unknown/unavailable/cached as appropriate, while File Sharing shortcuts still work.
5. On two real Android phones, test existing Send/Receive, QR and manual codes, explicit approval, small/multiple/zero-byte files, progress, cancellation/retry, final receipt, Saved Files/history and SHA-256.
6. For a future staging backend, authenticate a test user; validate server/cached labels, account switching, reward pending/approved/rejected, immutable transaction history and reversal rows. Repeated provider callbacks must not create duplicate credits.
7. With a staging payout adapter only, check minimum/balance/conflict/quote validation, duplicate taps, timeout and original-key reconciliation. Confirm requests never cause a local balance deduction. Do not interpret staging records as real payments.
8. Background/dispose the dashboard during reads, change account, resume and refresh; old-account data must not return.
9. On a real iPhone, separately test navigation, foreground handling, existing local-network/camera permissions, file sharing and native export. Mac/Xcode is required for the iPhone build.

## Known limitations

This is a foundation, not a production earning ecosystem. Sign-in providers, actual backend transport/storage, advertiser attribution, ad playback, daily/referral reward validation and payout providers are not connected. The offerwall is not yet the Part 6 large-catalog UI. Provider URLs/images are DTO data, not auto-opened/fetched resources. Cache/idempotency bookkeeping is bounded and memory-only; definitive anti-fraud and financial consistency require a backend. Existing foreground/private-IPv4/no-resume sharing limits remain.

# ▶ Next — Part 6 (File 26–30)
