# ShareBondhu — sequential file index, after Part 2

## User requirements

1. Deliver complete files, never shortened implementations or patch-only answers.
2. Preserve existing logic, endpoints and functions while adding new parts. Updated files must be shown in full.
3. Give new authored source/test files permanent sequential numbers. Existing paths keep their number on updates.
4. End each useful part with a Next option.
5. Flutter app for Android and iPhone; user has a computer. ShareBondhu and its application ID are temporary branding.

## Current file numbers

| Number | Path | Part 2 status |
|---|---|---|
| 1 | `pubspec.yaml` | Updated; version 0.2.0+2, all old direct dependencies retained |
| 2 | `lib/main.dart` | Unchanged, byte-identical to Part 1 |
| 3 | `lib/models/share_file.dart` | Unchanged, byte-identical to Part 1 |
| 4 | `lib/screens/home_screen.dart` | Updated; prior methods/selection behavior retained, nearby routes added |
| 5 | `test/widget_test.dart` | Updated; original 28 tests retained, 32 additional tests |
| 6 | `lib/models/transfer_models.dart` | New protocol, pairing, limits, receipt models |
| 7 | `lib/services/local_transfer_service.dart` | New real TLS receiver/sender implementation |
| 8 | `lib/screens/nearby_screen.dart` | New send/receive, consent, clipboard and native export interface |
| 9 | `android/app/src/main/AndroidManifest.xml` | First customization of generated scaffold; full previous configuration retained |
| 10 | `ios/Runner/Info.plist` | First customization of generated scaffold; full previous keys retained |

Scaffold files, generated plugin registrants, dependency lockfiles, assets and documentation are also included in the archive inventory. Number an unnumbered scaffold source if a later part customizes it by hand. Do not renumber current files.

## Current baseline

Version 0.2.0+2. Date: 2026-09-06. Flutter 3.47.2 / Dart 3.13.2, Linux verification.

Direct dependencies: file_picker 12.2.0, basic_utils 5.8.2, crypto 3.0.7, path_provider 2.1.6, share_plus 13.3.0. flutter_lints 6.0.0 remains. pubspec.lock pins the resolved transitive graph.

Static analysis is clean. 60 tests pass: 28 retained Part 1 tests, 8 protocol-model tests, 19 actual loopback TLS/network tests, 5 new navigation/lifecycle tests. Tests run real encrypted client/server transfers and compare saved bytes and hashes. Screenshots use injected sample file metadata and Flutter test rendering; they are not physical-device screenshots.

Native Android/iOS builds, cross-phone Wi-Fi/hotspot operation, real OS picker/permission/share-sheet flows and multi-GiB device stress are NOT yet verified. No APK/IPA is distributed. Android generated target/compile SDK is 36, min SDK 24. iOS deployment target is 15.0. Production signing and launcher icons are not finished.

## Part 1 contracts still present

- `ShareBondhuApp(pickFiles: ...)` injection, system/default theme behavior and light/dark toggle.
- `HomeScreen` picker callback and theme-toggle callback.
- `pickDeviceFiles()` uses file_picker 12's static API, does per-file metadata error handling, and returns immutable `FileSelection`.
- `ShareFile` keeps name, size, sourceUri and a lazy readStream factory. `openRead()` is still the content API. Removal/clear/selection metadata do not open the content stream or delete selected originals.
- ID is the source URI string, not a content hash. Preserve duplicate-reference suppression, including allowing same-name/different-source files.
- Keep picker cancellation, confirmation dialog, retry/error feedback, busy protection, mounted guards and navigation-state preservation.
- All original home methods are retained. Existing test keys and their behaviors remain.

## Part 2 contracts to preserve

- Manual pairing is a complete 98-character SB1 code. New QR work must encode/decode the SAME code and keep manual entry as a fallback, without weakening authentication into a short unauthenticated PIN.
- A pairing code contains a private IPv4 host, port, random invitation token and DER certificate SHA-256 pin. Never log it or the private key. Normal UI rejects loopback/public/DNS/IPv6 targets. Loopback is test-only opt-in.
- TLS identities are fresh per receiver session. The UI does not inject shared identities. Test fixtures reuse a generated identity for speed only within tests.
- All five v1 endpoints and their existing fields must remain compatible: POST offer, PUT files, POST commit, DELETE transfers, GET status. Read `PROTOCOL_V1.md` before modifying the engine.
- No original source path/URI is serialized to peers. Names are safe basenames. TLS is in-transit protection, not an at-rest encryption feature.
- Receiver approval must stay explicit for every batch; exceptions/timeouts/backgrounding do not auto-approve.
- Keep sequential upload, exact-length checks, bounded metadata, SHA-256 on both ends, staged files and final batch commit. Do not equate uploaded bytes with confirmed saved files.
- The sender owns a StreamIterator and awaits output flushing. Cancel the iterator before disposing its hash state. Feeding an unowned async generator to HttpClientRequest.addStream previously caused late events after abort; the current iterator approach fixes that race and has regression tests.
- Receiver staging cleanup is serialized, waits for open file I/O, preserves committed data, and reports storage failures. It uses receiver-owned `.incoming-sb1-` directories, never the source URI path.
- Invitation expiry, approval deadline, first/inter-file/commit idle lease and overall batch timeout are distinct. Keep the safeguards when adding QR/discovery.
- Final commit may finish during cancellation. Recover the latest completed receipt when possible; otherwise report an uncertain outcome instead of automatic retry or false failure/success.
- The nearby screen is opt-in. It stops on paused/hidden/detached lifecycle states and guards the asynchronous documents-directory lookup startup race. Inactive is not treated as background because permission dialogs can cause it.
- `NearbyScreen.documentsDirectory` defaults to path_provider's real app documents function; injection exists for lifecycle tests. No network listener starts merely by visiting the screen.
- Copies are in app Documents/ShareBondhu/Received. `transfer.json` records wire-safe metadata, not absolute paths. Saved filenames are the 1-based, 3-digit index, underscore and normalized display name. The batch directory has a generated `received-` name. Future history code can read these receipts and derive local paths safely.
- Native export uses SharePlus with file paths and an iPad share origin, without loading whole files into a byte array. A closed/successful share sheet does not prove an external destination saved the data; the UI asks users to check it.
- Keep manual entry, existing share/receive controls, selection retention and error feedback when adding new UI.

## Current limitations and next work

Only private IPv4 shared LAN/hotspot operation, foreground sessions, 50 files, 2 GiB/file and 4 GiB/batch are supported. No QR scanner, automatic discovery, Wi-Fi Direct parity with iPhone, automatic hotspot control, resumable/background transfer, history browser, ad SDK or store release readiness is claimed.

Start Part 3 at **File 11**. Planned group File 11–15: QR display/scanning and a saved-file/history interface using existing receipts. Update File 1 dependencies and existing platform files 9/10 in full if camera requirements change. Keep the manual pairing flow and all v1 endpoints.

Part 1 and Part 2 archives and standalone full-code guides should remain immutable. Continue in the working source tree and deliver a new versioned archive and complete code guide. Historical Part 1 checksum/inventory reports describe its archive, not the changed current tree.
