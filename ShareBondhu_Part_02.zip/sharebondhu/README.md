# ShareBondhu — Part 2

নিজের ব্র্যান্ডের Flutter Android + iPhone file-sharing অ্যাপের দ্বিতীয় ধাপ। **নতুন File 6–10**, সঙ্গে আগের প্রয়োজনীয় ফাইলগুলোর সম্পূর্ণ আপডেট। Part 1-এর selection, duplicate-reference handling, clear confirmation, light/dark theme ও navigation রাখা হয়েছে।

## এবার যা যোগ হয়েছে

- একই private IPv4 Wi-Fi/হটস্পটে manual pairing code দিয়ে সংযোগ।
- প্রতিটি receiving session-এ নতুন RSA-2048 self-signed TLS identity; sender তার certificate fingerprint pin করে। কোনো shared, hardcoded private key নেই।
- Receiver প্রতিটি batch-এর নাম/size দেখে Accept বা Decline করতে পারেন। Device name নিজে লেখা যায়, তাই সেটি পরিচয়ের প্রমাণ নয়।
- পুরো ফাইল RAM-এ না তুলে stream করে পাঠানো ও app documents-এ লেখা। Sender stream cancellation ও output backpressure সামলায়।
- দুই পাশে SHA-256 এবং প্রকৃত byte count যাচাই; সব file যাচাইয়ের পরে batch commit। শুধু 100% upload দেখিয়ে সফল বলা হয় না।
- Cancel, connection failure, approval/idle timeout, incomplete-file cleanup এবং শেষ confirmation হারালে receipt recovery-এর ব্যবস্থা।
- মূল নির্বাচিত ফাইল অপরিবর্তিত থাকে। একই নামের received file-ও unique batch directory ও numbered basename দিয়ে আলাদা থাকে।
- Received copies-এর জন্য system **Share / save copies** button। এতে native share sheet খোলে; কোনো destination-এ save সফল হয়েছে বলে অ্যাপ নিজে দাবি করে না।
- Android INTERNET permission, iOS local-network description ও Files-app document sharing configuration। HTTPS ব্যবহারে broad cleartext/ATS bypass যোগ করা হয়নি।

## গুরুত্বপূর্ণ সীমা

এটি একটি development MVP, store-ready release নয়। এই পরিবেশে static analysis, ৬০টি automated test এবং সত্যিকারের loopback HTTPS/TLS file transfer পরীক্ষা হয়েছে। **Android/iPhone native build, দুই বাস্তব ফোনের Wi-Fi connection, OS file picker, local-network permission prompt ও native share sheet এখানে পরীক্ষা হয়নি। APK/IPA এই ZIP-এ নেই।**

প্রতি batch: ১–৫০টি file, প্রতিটি সর্বোচ্চ **2 GiB**, মোট **4 GiB**। Metadata সর্বোচ্চ 64 KiB। File-provider-এর reported size অনুযায়ী শুরু হয়; বাস্তব stream ভিন্ন হলে transfer ব্যর্থ হবে, ভুলভাবে সফল নয়। Cloud-only file আগে local করতে internet লাগতে পারে।

Pairing code নতুন request-এর জন্য ১০ মিনিট valid। Approval-এর সময় ৬০ সেকেন্ড। Idle transfer-এর সময়সীমা ৩০ সেকেন্ড এবং accepted batch-এর সর্বোচ্চ সময় ৩০ মিনিট। Code expire হলেও আগেই accepted batch তার নিজের সময়সীমার মধ্যে শেষ হতে পারে।

**দুই অ্যাপ সামনে খোলা রাখুন।** Background/lock/screen leave-এ সক্রিয় কাজ বন্ধ করা হয়। Final commit শুরু হয়ে গেলে cancel-এর সময়েও receiver-এ batch saved হয়ে যেতে পারে; অনিশ্চিত confirmation হলে receiver দেখে তারপর retry করুন।

এখনো নেই: QR scanner, automatic discovery/hotspot creation, IPv6-only/public-address support, resumable/background transfer, persistent history browser, advertising এবং production signing। TLS পরিবহনের সুরক্ষা; app documents-এ সংরক্ষিত file-এর জন্য আলাদা at-rest encryption যোগ করা হয়নি। স্বাধীন security audit-ও হয়নি। নিজের trusted LAN-এ আগে পরীক্ষা করুন।

## চালু করার নিয়ম

পরীক্ষিত toolchain: **Flutter 3.47.2 / Dart 3.13.2**। Minimum constraints: Flutter 3.47.0 / Dart 3.13.0। Direct dependencies pin করা আছে এবং `pubspec.lock` দেওয়া হয়েছে। Flutter SDK ও platform toolchain আলাদাভাবে install করতে হবে।

Flutter install: https://docs.flutter.dev/install

Android Studio: https://developer.android.com/studio

ZIP extract করে `sharebondhu` directory-তে terminal খুলুন:

```bash
flutter --version
flutter doctor -v
flutter pub get
flutter analyze
flutter test
flutter devices
flutter run
```

আগের Part চলতে থাকলে **পুরো app stop করে rebuild করুন**। নতুন native plugins/permissions শুধু hot reload দিয়ে যোগ হবে না।

Android-এর জন্য Android Studio SDK/toolchain ও compatible Java 17+ JDK ব্যবহার করুন; Java 11 নয়। এই Flutter SDK-এর generated Android configuration target/compile SDK 36 এবং minimum SDK 24 ব্যবহার করছে। Target SDK ভবিষ্যতে বাড়ালে তখনকার local-network permission requirements আবার যাচাই করতে হবে।

নিজের PC-তে debug APK তৈরি করতে:

```bash
flutter build apk --debug
```

Output: `build/app/outputs/flutter-apk/app-debug.apk`। Android release template এখনো debug signing ব্যবহার করে; সেটি store-এ প্রকাশ করবেন না।

iPhone-এর জন্য Mac ও compatible Xcode প্রয়োজন। Generated iOS deployment target 15.0। বাস্তব iPhone-এ Xcode signing team লাগবে। Windows/Linux থেকে স্থানীয় iOS build হবে না। Mac-এ Simulator খুলতে:

```bash
open -a Simulator
flutter devices
flutter run
```

## দুই ফোনে ব্যবহার: প্রথম পরীক্ষাটি ছোট file দিয়ে করুন

1. দুই ফোনে app install/run করুন এবং একই private IPv4 Wi-Fi-তে রাখুন। অথবা এমন hotspot ব্যবহার করুন যেখানে device-to-device traffic অনুমোদিত। Guest Wi-Fi/client isolation/VPN সংযোগে বাধা দিতে পারে।
2. **গ্রহণকারী ফোন:** Home → **Receive files → Start receiving**। iOS local-network permission চাইলে বুঝে অনুমতি দিন।
3. একাধিক address দেখালে অন্য ফোন থেকে পৌঁছানো যায় এমন Wi-Fi address বাছুন। **Copy code** চাপুন।
4. **Copy code শুধু সেই ফোনের clipboard-এ কপি করে; অন্য ফোনে নিজে থেকে পৌঁছায় না।** এই Part-এর ৯৮ অক্ষরের সম্পূর্ণ `SB1` code অন্য ফোনে নিজে লিখুন বা আপনার পছন্দের private মাধ্যম দিয়ে দিন। Code-এ authentication secret আছে; public post করবেন না। QR pairing পরের Part-এ যোগ হবে। Third-party মাধ্যমে code দেওয়ার জন্য internet লাগতে পারে; file-transfer channel নিজে local।
5. **পাঠানোর ফোন:** Select files → Files tab → **Send selected**। Device name লিখুন, receiver code paste করুন, **Ask to send** চাপুন।
6. **গ্রহণকারী ফোন:** নাম/size এবং sender যাচাই করে **Accept files** চাপুন। Device name self-reported। অচেনা request Decline করুন।
7. Sender-এ **Delivery confirmed** এবং receiver-এ **Saved and verified** দেখা পর্যন্ত অপেক্ষা করুন। Progress-এর byte count final delivery receipt নয়।
8. Receiver-এর **Share / save copies** দিয়ে system share sheet খুলুন। iPhone-এ Save to Files বেছে নেওয়া যায়। Android-এ available destination installed app-এর ওপর নির্ভর করে।

Received data থাকে app Documents-এর `ShareBondhu/Received` directory-তে। iOS-এ Files app-এ ShareBondhu document folder-ও দেখা যেতে পারে। Android-এ এগুলো app-specific documents; public Downloads-এ নিজে থেকে লেখা হয় না। Export গুরুত্বপূর্ণ file, বিশেষ করে uninstall/clear app data-এর আগে। এই Part-এ history browser নেই; receipt card বর্তমান screen/session-এর জন্য। Saved data disk-এ থাকে, কিন্তু app data মুছলে তা হারাতে পারেন। Device backup/cloud behavior OS settings-এর ওপর নির্ভর করে।

## Part 1 থেকে কী বদলেছে

| File | Path | অবস্থা |
|---|---|---|
| 1 | `pubspec.yaml` | UPDATED — version 0.2.0+2, TLS/storage/share dependencies যোগ |
| 2 | `lib/main.dart` | UNCHANGED — আগের সঙ্গে byte-for-byte একই |
| 3 | `lib/models/share_file.dart` | UNCHANGED — আগের সঙ্গে byte-for-byte একই |
| 4 | `lib/screens/home_screen.dart` | UPDATED — পুরোনো logic রেখে send/receive route ও guide যোগ |
| 5 | `test/widget_test.dart` | UPDATED — আগের ২৮টি test রেখে আরও ৩২টি test যোগ |
| 6 | `lib/models/transfer_models.dart` | NEW — pairing, limits, protocol models, receipts |
| 7 | `lib/services/local_transfer_service.dart` | NEW — TLS receiver/sender, streaming, consent, commit ও cleanup |
| 8 | `lib/screens/nearby_screen.dart` | NEW — send/receive interface ও foreground lifecycle |
| 9 | `android/app/src/main/AndroidManifest.xml` | FIRST CUSTOMIZATION — permission/name; আগের entries অক্ষুণ্ণ |
| 10 | `ios/Runner/Info.plist` | FIRST CUSTOMIZATION — local-network/Files support; আগের entries অক্ষুণ্ণ |

`pubspec.lock` ও plugin registrants tooling দিয়ে regenerate হয়েছে। এগুলো numbered authored source নয়। ZIP-এ standard Android/iOS scaffold, assets ও Gradle wrapper-ও আছে। SDK, package caches, compiled output ও machine-specific generated paths বাদ রাখা হয়েছে; Flutter tools সেগুলো পুনরায় তৈরি করবে।

## ফাইলগুলো

- `docs/PART_02_FULL_CODE.md`: নতুন File 6–10 এবং আগের File 1–5-এর সম্পূর্ণ বর্তমান কোড; কোনো implementation বাদ নেই।
- `docs/PROTOCOL_V1.md`: endpoint, trust model ও lifecycle।
- `docs/FILE_INDEX.md`: স্থায়ী file numbers ও পরের Part-এর compatibility notes।
- `docs/PART_02_TEST_RESULTS.txt`: বর্তমান analysis ও ৬০টি test-এর output।
- `docs/FILE_INVENTORY.txt`, `docs/SHA256SUMS.txt`: এই ZIP-এর inventory ও checksum।
- `docs/part02-preview.png`: test-rendered UI; ছবি/নাম/size test data, physical-phone screenshot নয়।
- Part 1 guide ও historical reports আলাদা নামে রাখা হয়েছে। Part 1 archive ও তার standalone full-code guide বদলানো হয়নি।

ShareBondhu নাম ও `com.sharebondhu.sharebondhu` ID এখনো অস্থায়ী। Publishing-এর আগে brand availability, application ID, launcher icons, signing ও privacy/compliance যাচাই বাকি।

## Next — Part 3

চ্যাটে **Next** লিখুন। পরের ধাপে **File 11–15** দিয়ে QR pairing এবং saved-file/history interface যোগ করব; manual pairing ও বর্তমান transfer endpoints অক্ষুণ্ণ থাকবে।
