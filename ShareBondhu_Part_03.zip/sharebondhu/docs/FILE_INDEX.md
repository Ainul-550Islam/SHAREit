# ShareBondhu — sequential file index, after Part 3

## User requirements

- Full source files only: no shortened implementations and no patch-only deliverables.
- Preserve all existing logic, endpoints and functions when extending a part; show the complete updated file.
- Assign permanent sequential numbers to new authored source/test files. Updates retain their original number.
- End each part with a Next option.
- Flutter, Android + iPhone, computer-based development. ShareBondhu and the application ID remain temporary branding.

## Permanent file numbers

| File | Path | Part 3 state |
|---|---|---|
| 1 | `pubspec.yaml` | Updated, version 0.3.0+3; all old dependencies retained |
| 2 | `lib/main.dart` | Unchanged from Part 2 |
| 3 | `lib/models/share_file.dart` | Unchanged from Part 2 |
| 4 | `lib/screens/home_screen.dart` | Updated; old methods kept, Saved files route added |
| 5 | `test/widget_test.dart` | Updated; original 60 tests plus 37 new tests |
| 6 | `lib/models/transfer_models.dart` | Unchanged from Part 2 |
| 7 | `lib/services/local_transfer_service.dart` | Unchanged from Part 2 |
| 8 | `lib/screens/nearby_screen.dart` | Updated; QR/manual coexist, status/approval prioritized |
| 9 | `android/app/src/main/AndroidManifest.xml` | Updated; optional camera additions |
| 10 | `ios/Runner/Info.plist` | Updated; camera usage description only added |
| 11 | `lib/models/saved_transfer.dart` | New; immutable history/status models, strict receipt parser, cancellation |
| 12 | `lib/services/transfer_history_service.dart` | New; read-only bounded discovery, hash verification and share preparation |
| 13 | `lib/screens/history_screen.dart` | New; search, filters, details, verify/cancel and re-share |
| 14 | `lib/widgets/pairing_qr_card.dart` | New; SB1 QR image with quiet zone and expiry |
| 15 | `lib/screens/scan_pairing_screen.dart` | New; native camera adapter, opt-in scanner, validation/confirmation |

Generated scaffold/assets, plugin registrants, lockfiles and documentation also ship in the source archive. Assign a number to an unnumbered scaffold source only if it is customized by hand in a later part. Do not renumber existing files.

## Verified baseline

Date: 2026-09-06. Flutter 3.47.2 release tag / Dart 3.13.2 on Linux. Version 0.3.0+3.

All prior direct dependencies remain. New pinned direct dependencies: qr_flutter 4.1.0, mobile_scanner 7.4.0 and path 1.9.1. pubspec.lock contains the resolved graph.

Static analysis is clean. 97 tests pass: 60 retained, then 3 history-model, 15 real filesystem/legacy-TLS compatibility, 3 QR-widget, 9 camera/QR-flow and 7 history-UI tests. Camera tests inject a test adapter; native device camera capture is not tested. Separate QA software-decodes two actual Flutter-rendered QR images to the exact full SB1 payloads.

Files 2, 3, 6 and 7 are byte-identical to Part 2. Existing Home/Nearby methods and prior iOS plist values are retained. Earlier versioned ZIPs and full-code guides remain immutable.

Still NOT verified: Android/iOS native compilation, physical phone camera/permission/share-sheet behavior, two-phone Wi-Fi/hotspot interoperability, multi-GiB device stress or store release readiness. No APK/IPA is distributed. Preview QR is an explicitly labeled component demo with no active receiver.

## Retained Part 1 contracts

- ShareBondhuApp accepts picker injection and still owns the system/light/dark theme logic.
- HomeScreen keeps picker/theme callbacks, old tabs and selection state. Its additional historyScreenBuilder has a real default and permits navigation tests without native storage calls.
- pickDeviceFiles uses file_picker 12's static API; cancellation and per-file failures preserve valid existing selections.
- ShareFile keeps name, size, sourceUri and lazy readStream/openRead. Selecting/removing/clearing references must not read or delete original content.
- Preserve URI-reference deduplication while allowing the same filename from distinct sources; this is not content-level deduplication.
- Keep busy protection, mounted guards, confirmation dialog, retry/error messages, theme changes, navigation and existing test keys.

## Retained Part 2 contracts

- SB1 remains a full 98-character code: private IPv4, port, 32 random invitation bytes and DER certificate SHA-256. Manual entry/copy stays available. No short unauthenticated PIN replacement.
- Fresh receiver TLS identity; exact pin/host/port checking; no blanket certificate acceptance, public/DNS/IPv6 destinations, redirects or proxies. Loopback is only explicit engine-test opt-in, not normal UI parsing.
- Keep the five v1 endpoints and existing fields: POST offer, PUT files, POST commit, DELETE transfers, GET status. Read PROTOCOL_V1.md before engine edits.
- Preserve explicit per-batch approval, sequential streaming, exact size/hash checks, bounded metadata, staged atomic commit, original-file retention, cancel/cleanup, separate idle/approval/invitation/batch deadlines and uncertain final-confirmation handling.
- The sender must continue to own and cancel its stream iterator before closing hash state. An earlier unowned async-generator/addStream approach caused late events after abort; current code and regression tests avoid that race.
- No local source URI/path is sent to a peer. Native receive-screen share remains available. A closed share sheet is not proof of an external save.
- Nearby is foreground/opt-in, including the asynchronous storage-lookup startup race. Active requests/progress are now before the QR panel and can focus the scroll position so consent is not hidden.
- Documents/ShareBondhu/Received stores unique receiver-generated received-* directories. A receipt has wire-safe metadata; file disk names use 1-based three-digit index, underscore and safe display name.

## New Part 3 contracts

- PairingQrCard directly encodes PairingCode.encode, with white background, black modules, medium error correction, 24-pixel padding and no embedded logo. Hide expired QR images; the existing engine still authorizes the session. Expiry is not encoded in SB1 itself.
- Scanner uses an injectable PairingCamera interface; real default wraps mobile_scanner. Camera starts only through Start camera, stops after capture/background/disposal and handles late startup. Resuming does not auto-start it.
- Invalid/URL QR content is neither opened nor shown verbatim. A valid code is only a format-valid candidate, not a verified connection. Use this code fills the form; Ask to send and receiver acceptance remain separate. Scanner cancel preserves existing manual text.
- Camera permission is optional, with manual fallback. No microphone/gallery permission or image-save/upload action is added. Default bundled Android barcode model remains configured.
- History uses the receiving directory name as identity; wire IDs can repeat across batches. Read Part 2 receipts without migration or mutation.
- Validate folder names, bounded JSON, UTC timestamps, counts/sizes/hashes, unique file IDs and safe basenames. Derive file paths from checked folder and list position; ignore serialized localPath fields.
- Reject linked/unsafe roots, folders, receipts and listed files using type and canonical-path checks. Static path safety is not a race-free defense against hostile local filesystem control.
- Listing checks only presence/size. Keep available distinct from checksum-verified, missing, changed, unsafe and unreadable.
- Verify streams bytes with owned/cancelable iterators, checks hash/size/mtime/path, and rejects a receipt that changes from the displayed snapshot. History share preparation repeats checks for selected files. Single-file sharing may succeed when another file in the batch is missing.
- No history delete/rename, automatic repair, database migration, signed receipt or at-rest encryption is implemented. Checks compare stored receipts, not authenticated original history after hostile local edits. Status is session-only.
- History limits: 250 returned batches and 2000 inspected root entries by default. Show skipped/truncated warnings. Never delete data to satisfy the limits.
- History loading/operations ignore stale generations and cancel on background/dispose. UI supports injectable service, documents provider and share action for tests; actual defaults use path_provider/share_plus.
- Keep the distinct PageStorageKey on each SelectableText checksum inside an ExpansionTile. Without it, text scroll restoration collides with the tile's boolean expansion state and throws a bool-to-double error.
- Native export passes file paths and iPad share origin, not a full in-memory byte array. The history UI accurately says to check the destination after the share sheet closes.

## Next part

Start at **File 16**. Planned Part 4 group File 16–20: settings/branding and device-test/release-preparation work. Preserve QR, manual entry, history, all endpoints and all existing tests. Ask for real branding details before publishing; the current name/ID are still temporary.

Do not claim ads, automatic discovery/hotspot creation, resumable/background transfer, IPv6-only support, sent-history storage, physical-device verification or store readiness as completed. New native or signing work must include full updated files and honest test scope.
