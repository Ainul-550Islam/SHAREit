# ShareBondhu — Part 3

নিজের ব্র্যান্ডের Flutter Android + iPhone অ্যাপের তৃতীয় ধাপ। **নতুন File 11–15**: QR display/scanner ও saved-file history। আগের manual pairing, selection, theme, receiver approval ও TLS transfer রাখা হয়েছে। নতুন database বা পুরোনো received files migrate করার দরকার নেই।

## এই Part-এ যা যোগ হয়েছে

- Receiver-এর একই **৯৮ অক্ষরের SB1 code** এখন QR হিসেবে দেখানো হয়। QR-এর নিচে আগের manual code ও Copy code আছে।
- QR-তে white quiet zone, black modules, expiry countdown; invitation expire হলে QR লুকানো হয়। নতুন code নিজে থেকে তৈরি হয় না।
- Sender-এর **Scan receiver QR → Start camera → Use this code** flow। তারপরও **Ask to send** চাপতে হয় এবং receiver-কে **Accept** করতে হয়। স্ক্যান কোনো network request বা file transfer নিজে থেকে শুরু করে না।
- Camera permission optional; না দিলে manual pairing চালু থাকে। Arbitrary URL/অন্য QR খোলা হয় না। Duplicate detection, pause, retry, flashlight এবং startup/background/disposal guard আছে।
- Home-এর **Saved files**: Part 2 ও পরের receiving session-এর `transfer.json` পড়ে batch, sender, সময়, filename ও recorded size দেখায়।
- Local search, Available / Needs attention filter, missing/changed/unreadable file status এবং **Verify checksums**। শুধু size মিলে গেলে বর্তমানে verified বলা হয় না।
- History থেকে একটি file বা পুরো batch আবার share করা যায়। History-এর share action আগে সংশ্লিষ্ট file-এর SHA-256 পরীক্ষা করে, তারপর native share sheet খোলে।
- History read-only: কোনো delete, rename, receipt rewrite, automatic repair বা original source file পরিবর্তনের ব্যবস্থা যোগ করা হয়নি।

## কী অপরিবর্তিত

**File 2, 3, 6 ও 7 Part 2-এর সঙ্গে byte-for-byte একই।** অর্থাৎ app entry/theme, selected-file model, SB1 protocol model এবং সম্পূর্ণ TLS engine অপরিবর্তিত। পাঁচটি v1 endpoint-ও একই আছে। File 4 ও 8-এর আগের methods রেখে নতুন UI যোগ হয়েছে। Camera permission ছাড়া iOS-এর আগের keys বদলানো হয়নি; Android-এর আগের permission/activity/query রাখা হয়েছে।

## পরীক্ষার ফল ও সীমা

- Flutter static analysis: **No issues found**।
- **৯৭টি automated test পাস**: আগের ৬০টি এবং নতুন ৩৭টি।
- Actual filesystem history, hash checking, changed/missing copies, symlink rejection, cancellation এবং আগের TLS engine-এর output history-তে পড়ার পরীক্ষা হয়েছে।
- Flutter-rendered QR-এর দুইটি demo payload software decoder দিয়ে আবার পড়ে সম্পূর্ণ ৯৮ অক্ষরের SB1 data মিলিয়ে দেখা হয়েছে।
- Camera lifecycle/permission/UI পরীক্ষায় **test camera** ব্যবহার হয়েছে। এটি বাস্তব camera test নয়।

**এই পরিবেশে Android/iPhone native compilation, দুই ফোনের Wi-Fi transfer, বাস্তব camera scan, native permission prompt এবং share sheet যাচাই করা হয়নি। ZIP-এ তৈরি APK/IPA নেই। এটি development MVP, store-ready release নয়।**

## কম্পিউটারে চালান

পরীক্ষিত toolchain: **Flutter 3.47.2 / Dart 3.13.2**। Minimum: Flutter 3.47.0 / Dart 3.13.0। আগের direct dependencies রাখা হয়েছে; নতুন pinned dependencies: `qr_flutter 4.1.0`, `mobile_scanner 7.4.0`, `path 1.9.1`। Transitive graph `pubspec.lock`-এ আছে।

Flutter install: https://docs.flutter.dev/install

Android Studio: https://developer.android.com/studio

ZIP extract করে `sharebondhu` folder-এ terminal খুলুন:

```bash
flutter --version
flutter doctor -v
flutter pub get
flutter analyze
flutter test
flutter devices
flutter run
```

**আগের app পুরো stop করে rebuild করুন।** Camera/native plugin যোগ হওয়া শুধু hot reload দিয়ে কার্যকর হবে না। প্রথমে আগের project backup রাখুন। এই ZIP-এ standard Android/iOS runner, assets, Gradle wrapper ও complete source আছে; SDK/cache/build output/machine-specific configuration নেই। Flutter tools সেগুলো regenerate করে।

Android: Android Studio SDK/toolchain ও compatible Java 17+ JDK দরকার; Java 11 নয়। বর্তমান generated configuration target/compile SDK 36, minimum SDK 24। Camera hardware optional ঘোষণা করা হয়েছে, যাতে camera ছাড়া device-এ manual mode রাখা যায়। Future target-SDK upgrade-এর আগে নতুন permission requirements যাচাই করতে হবে।

নিজের কম্পিউটারে debug APK:

```bash
flutter build apk --debug
```

Output: `build/app/outputs/flutter-apk/app-debug.apk`। এটি development build; release signing এখনো প্রস্তুত নয়।

iPhone: Mac ও compatible Xcode দরকার; real device-এর জন্য signing team। iOS deployment target 15.0। Windows/Linux থেকে স্থানীয় iOS build নয়। Mac-এ:

```bash
open -a Simulator
flutter devices
flutter run
```

Camera feature পরীক্ষা করতে উপযুক্ত বাস্তব device ব্যবহার করুন। Simulator/no-camera environment-এ manual pairing ব্যবহার করুন।

## QR দিয়ে দুই ফোনে ব্যবহার

1. দুই ফোনে app চালিয়ে একই private IPv4 Wi-Fi বা device-to-device traffic অনুমোদিত hotspot-এ রাখুন। QR নিজে Wi-Fi connection তৈরি করে না।
2. **গ্রহণকারী:** Home → Receive files → Start receiving। Local-network permission চাইলে পর্যালোচনা করে অনুমতি দিন।
3. একাধিক IP থাকলে সঠিক Wi-Fi address বাছুন। Receiver-এর QR শুধু যাঁকে পাঠাতে দেবেন তাঁকেই দেখান—QR-তে authentication secret আছে। Public post করবেন না।
4. **পাঠানো ফোন:** Select files → Files → Send selected → Scan receiver QR → Start camera। চাইলে camera permission দিন।
5. QR পাওয়ার পরে address/pin ও সতর্কতা দেখুন। **Use this code** code field পূরণ করে; তখনো file পাঠায় না।
6. Sender **Ask to send** চাপবেন। Receiver file list দেখে **Accept files** চাপবেন। Device name self-reported, তাই পরিচয়ের নিশ্চয়তা নয়।
7. Receiver-এর Saved and verified এবং sender-এর Delivery confirmed পর্যন্ত অপেক্ষা করুন। 100% upload final receipt নয়।

Camera না চাইলে **Use manual code instead** দিয়ে ফিরে paste করুন। Part 2-এর code একইভাবে কাজ করে। পুরোনো/expired QR format হিসেবে valid হতে পারে, কিন্তু receiver তা গ্রহণ নাও করবে; fresh receiving session-এর QR নিন। Android scanner-এর default bundled on-device barcode model configuration রাখা হয়েছে, unbundled first-use model download চালু করা হয়নি। এই app-এর scanner flow camera image save/upload করে না; SDK/store privacy review তবুও publishing-এর আগে বাকি।

## সংরক্ষিত file খুঁজুন ও আবার share করুন

1. চলতি receiving screen ছাড়তে হলে আগের Stop/leave confirmation ব্যবহার করুন। এরপর Home → **Saved files**।
2. এটি **received copies-এর ইতিহাস**; sent-history database নয়। Part 2-এর completed receipts সরাসরি পড়া হয়।
3. Batch খুললে filename, size, receipt SHA-256 ও বর্তমান availability দেখবেন। Search দিয়ে name/sender খুঁজতে পারবেন।
4. **Verify checksums** দিলে file stream করে SHA-256 পুনরায় পরীক্ষা হয়। Cancel করলে বা app background হলে check বন্ধ হয়; saved data মুছে যায় না।
5. **Share all copies** বা file-এর share icon সংশ্লিষ্ট copies যাচাই করে native share sheet খোলে। কোনো copy missing/changed হলে সেটি share করার আগে সমস্যা দেখানো হয়।
6. Share sheet বন্ধ হওয়া মানেই অন্য app file save করেছে এমন দাবি করা হয় না—নিজের chosen destination যাচাই করুন। Receive screen-এর আগের Share / save copies-ও রাখা হয়েছে।

Saved copies app Documents-এর `ShareBondhu/Received` folder-এ থাকে। History engine শুধু receiver-generated `received-` folders ও valid receipts পড়ে; `.incoming-` staging ignore করে। Serialized external path ব্যবহার করে না; unsafe links/receipts reject করে। Default scan cap: 250 shown batches, 2000 root entries inspected; সীমা এলে UI জানায়। কোনো archive delete হয় না।

Verification status বর্তমান screen/session-এর জন্য; disk-এ নতুন verified flag লেখা হয় না। File বা receipt পরে বদলাতে পারে। SHA-256 stored receipt-এর সঙ্গে তুলনা করে—receipt নিজে cryptographically signed নয়। Hostile local filesystem race/tampering-এর সম্পূর্ণ প্রতিরোধ বা independent security audit দাবি করা হয়নি। আলাদা at-rest encryption নেই। App uninstall/clear-data-এর আগে গুরুত্বপূর্ণ copies export করুন; OS backup policy প্রযোজ্য।

## আগের transfer সীমা একই

১–৫০টি file, প্রতিটি সর্বোচ্চ 2 GiB, batch-এ মোট 4 GiB। Invitation ১০ মিনিট, receiver approval ৬০ সেকেন্ড; transfer idle/overall deadlines আগের মতো। দুই app foreground-এ রাখুন। Auto-discovery/hotspot control, IPv6-only transfer, resumable/background transfer এবং বিজ্ঞাপন এখনো যোগ হয়নি। Cloud-only source file local করতে internet লাগতে পারে। Final commit-এর সময় cancellation হলে receipt দেখে ফল নিশ্চিত করুন; অনিশ্চিত অবস্থায় blind retry করবেন না।

## ফাইল নম্বর

| File | Path | Part 3 |
|---|---|---|
| 1 | `pubspec.yaml` | UPDATED |
| 2 | `lib/main.dart` | UNCHANGED |
| 3 | `lib/models/share_file.dart` | UNCHANGED |
| 4 | `lib/screens/home_screen.dart` | UPDATED |
| 5 | `test/widget_test.dart` | UPDATED; আগের 60টি test retained |
| 6 | `lib/models/transfer_models.dart` | UNCHANGED |
| 7 | `lib/services/local_transfer_service.dart` | UNCHANGED |
| 8 | `lib/screens/nearby_screen.dart` | UPDATED |
| 9 | `android/app/src/main/AndroidManifest.xml` | UPDATED; optional camera permission/feature |
| 10 | `ios/Runner/Info.plist` | UPDATED; camera usage description |
| 11 | `lib/models/saved_transfer.dart` | NEW |
| 12 | `lib/services/transfer_history_service.dart` | NEW |
| 13 | `lib/screens/history_screen.dart` | NEW |
| 14 | `lib/widgets/pairing_qr_card.dart` | NEW |
| 15 | `lib/screens/scan_pairing_screen.dart` | NEW |

`docs/PART_03_FULL_CODE.md`-এ নতুন File 11–15 এবং আগের File 1–10-এর পুরো বর্তমান কোড আছে। `docs/FILE_INVENTORY.txt`-এ ZIP-এর সব file, `docs/SHA256SUMS.txt`-এ checksum, এবং `docs/PART_03_TEST_RESULTS.txt`-এ verification output আছে। Historical Part 1/2 documents ও archive অপরিবর্তিত রাখা হয়েছে। Preview-তে test data এবং একটি QR component demo আছে; demo QR কোনো active receiver নয়।

ShareBondhu নাম ও `com.sharebondhu.sharebondhu` ID অস্থায়ী। Brand availability, final launcher icon, signing, privacy declaration, real-device QA ও store release preparation বাকি।

## Next — Part 4 (File 16–20)

চালিয়ে যেতে চ্যাটে **Next** লিখুন। পরের ধাপে settings/branding ও device-test/release-preparation কাজ এগোব; বর্তমান QR, manual pairing, history ও v1 transfer flow অক্ষুণ্ণ থাকবে।
