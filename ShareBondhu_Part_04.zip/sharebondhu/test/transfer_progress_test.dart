import 'dart:async';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sharebondhu/models/share_file.dart';
import 'package:sharebondhu/models/saved_transfer.dart';
import 'package:sharebondhu/models/transfer_activity.dart';
import 'package:sharebondhu/models/transfer_models.dart';
import 'package:sharebondhu/screens/history_screen.dart';
import 'package:sharebondhu/screens/nearby_screen.dart';
import 'package:sharebondhu/services/local_transfer_service.dart';
import 'package:sharebondhu/services/transfer_history_service.dart';
import 'package:sharebondhu/services/transfer_progress_controller.dart';
import 'package:sharebondhu/widgets/transfer_progress_panel.dart';
import 'package:sharebondhu/widgets/transfer_result_panel.dart';

import 'widget_test.dart' as baseline;

class ProgressProbe {
  ProgressProbe({
    List<int> sizes = const <int>[1000],
    this.role = TransferRole.sender,
  }) {
    files = List<OfferedFile>.generate(
      sizes.length,
      (i) => OfferedFile(
        id: randomTransferId(),
        name: 'file-$i.bin',
        size: sizes[i],
      ),
    );
    controller = TransferProgressController(
      clock: () => time,
      autoRefresh: false,
    );
    epoch = controller.open(role);
    addTearDown(controller.dispose);
  }
  final TransferRole role;
  final String id = randomTransferId();
  String attempt = randomTransferId();
  late List<OfferedFile> files;
  late TransferProgressController controller;
  late int epoch;
  int sequence = 0;
  Duration time = Duration.zero;
  TransferActivity get state => controller.value;

  TransferProgress frame(
    TransferPhase phase, {
    int? bytes,
    int? done,
    int? checked,
    int? index,
    int? fileBytes,
    bool commit = false,
    TransferReceipt? receipt,
  }) {
    final active = index ?? state.progress.currentFileIndex;
    return TransferProgress(
      phase: phase,
      message: 'Engine event: ${phase.name}',
      transferId: id,
      attemptId: attempt,
      sequence: ++sequence,
      manifest: files,
      totalBytes: files.fold<int>(0, (sum, file) => sum + file.size),
      totalFiles: files.length,
      processedBytes: bytes ?? state.batchBytes,
      completedFiles: done ?? state.completedFiles,
      verifiedFiles: checked ?? state.verifiedFiles,
      currentFileIndex: active,
      currentFileTotalBytes:
          active == null || active >= files.length || active < 0
          ? null
          : files[active].size,
      currentFileBytes: active == null
          ? null
          : fileBytes ?? state.fileBytes ?? 0,
      fileName: active == null || active >= files.length || active < 0
          ? null
          : files[active].name,
      commitStarted: commit,
      receipt: receipt,
    );
  }

  bool step(
    TransferPhase phase, {
    int? bytes,
    int? done,
    int? checked,
    int? index,
    int? fileBytes,
    bool commit = false,
    TransferReceipt? receipt,
  }) => controller.addEngineEvent(
    epoch,
    frame(
      phase,
      bytes: bytes,
      done: done,
      checked: checked,
      index: index,
      fileBytes: fileBytes,
      commit: commit,
      receipt: receipt,
    ),
  );

  void start() {
    if (role == TransferRole.sender) step(TransferPhase.connecting);
    step(TransferPhase.awaitingApproval);
    step(TransferPhase.approved);
    step(TransferPhase.preparing, index: 0, fileBytes: 0);
    step(
      role == TransferRole.sender
          ? TransferPhase.sending
          : TransferPhase.receiving,
    );
  }

  TransferReceipt receipt({String? digest}) => TransferReceipt(
    id: id,
    senderName: 'Test peer',
    completedAt: DateTime.utc(2026, 9, 8),
    files: files.map(
      (file) => ReceivedFile(
        id: file.id,
        name: file.name,
        size: file.size,
        digest: digest ?? sha256.convert(<int>[1]).toString(),
      ),
    ),
  );

  void finishBytes() {
    for (var index = 0; index < files.length; index += 1) {
      if (index > 0) step(TransferPhase.preparing, index: index, fileBytes: 0);
      final bytes = files
          .take(index + 1)
          .fold<int>(0, (sum, file) => sum + file.size);
      step(
        role == TransferRole.sender
            ? TransferPhase.sending
            : TransferPhase.receiving,
        index: index,
        fileBytes: files[index].size,
        bytes: bytes,
        done: index + 1,
        checked: role == TransferRole.sender ? index + 1 : 0,
      );
    }
  }
}

// Test-only sender: production NearbyScreen still defaults to LocalSender.new.
class ControlledSender extends LocalSender {
  final Completer<TransferReceipt> completion = Completer<TransferReceipt>();
  late IncomingOffer offer;
  void Function(TransferProgress)? callback;
  int sequence = 0;
  int cancellations = 0;
  @override
  Future<TransferReceipt> send({
    required PairingCode code,
    required List<ShareFile> files,
    required String senderName,
    void Function(TransferProgress)? onProgress,
  }) {
    offer = createOutgoingOffer(files, senderName);
    callback = onProgress;
    emit(TransferPhase.connecting);
    emit(TransferPhase.awaitingApproval);
    return completion.future;
  }

  void emit(
    TransferPhase phase, {
    bool full = false,
    TransferReceipt? receipt,
  }) {
    callback?.call(
      TransferProgress(
        phase: phase,
        message: 'Controlled UI-test event',
        transferId: offer.id,
        attemptId: offer.id,
        sequence: ++sequence,
        manifest: offer.files,
        totalBytes: offer.totalBytes,
        totalFiles: offer.files.length,
        processedBytes: full ? offer.totalBytes : 0,
        completedFiles: full ? offer.files.length : 0,
        verifiedFiles: full ? offer.files.length : 0,
        receipt: receipt,
      ),
    );
  }

  @override
  void cancel() {
    cancellations += 1;
    if (!completion.isCompleted) {
      completion.completeError(const TransferCancelled());
    }
  }

  void fail() {
    if (!completion.isCompleted) {
      completion.completeError(
        const TransferException('Test source became unreadable.'),
      );
    }
  }

  void confirm() {
    final receipt = TransferReceipt(
      id: offer.id,
      senderName: offer.senderName,
      completedAt: DateTime.utc(2026, 9, 8),
      files: offer.files.map(
        (file) => ReceivedFile(
          id: file.id,
          name: file.name,
          size: file.size,
          digest: sha256.convert(<int>[1]).toString(),
        ),
      ),
    );
    emit(TransferPhase.approved);
    emit(TransferPhase.sending, full: true);
    emit(TransferPhase.completed, full: true, receipt: receipt);
    completion.complete(receipt);
  }
}

Future<void> mountSender(WidgetTester tester, ControlledSender sender) async {
  tester.view.physicalSize = const Size(390, 1100);
  tester.view.devicePixelRatio = 1;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);
  await tester.pumpWidget(
    MaterialApp(
      home: NearbyScreen(
        mode: NearbyMode.send,
        files: <ShareFile>[baseline.sampleFile(size: 3)],
        senderFactory: () => sender,
      ),
    ),
  );
  await tester.pumpAndSettle();
  await tester.enterText(
    find.byKey(const ValueKey('pairing-code-field')),
    baseline.qrTestCode().encode(),
  );
  final button = find.byKey(const ValueKey('ask-to-send-button'));
  await tester.ensureVisible(button);
  await tester.pumpAndSettle();
  await tester.tap(button);
  await tester.pump();
}

void main() {
  group('Part 4 controller', () {
    test('01 initial idle state', () {
      final p = ProgressProbe();
      expect(p.state.phase, TransferPhase.idle);
      expect(p.state.percentage, 0);
      expect(p.state.eta, isNull);
      expect(p.state.canCancel, isFalse);
    });
    test('02 connecting state', () {
      final p = ProgressProbe();
      expect(p.step(TransferPhase.connecting), isTrue);
      expect(p.state.phase, TransferPhase.connecting);
      expect(p.state.batchBytes, 0);
    });
    test('03 waiting for approval has no file bytes', () {
      final p = ProgressProbe();
      p.step(TransferPhase.connecting);
      p.step(TransferPhase.awaitingApproval);
      expect(p.state.phase, TransferPhase.awaitingApproval);
      expect(p.state.currentFileNumber, isNull);
    });
    test('04 approval is a distinct real-engine state', () {
      final p = ProgressProbe();
      p.step(TransferPhase.connecting);
      p.step(TransferPhase.awaitingApproval);
      p.step(TransferPhase.approved);
      expect(p.state.phase, TransferPhase.approved);
      expect(p.state.successfulFiles, 0);
    });
    test('05 sending counters come from events', () {
      final p = ProgressProbe()..start();
      p.step(TransferPhase.sending, bytes: 100, fileBytes: 100);
      expect(p.state.phase, TransferPhase.sending);
      expect(p.state.batchBytes, 100);
      expect(p.state.fileBytes, 100);
    });
    test('06 receiver uses the same progress abstraction', () {
      final p = ProgressProbe(role: TransferRole.receiver)..start();
      p.step(TransferPhase.receiving, bytes: 80, fileBytes: 80);
      expect(p.state.phase, TransferPhase.receiving);
      expect(p.state.role, TransferRole.receiver);
    });
    test('07 verifying is not completed', () {
      final p = ProgressProbe()
        ..start()
        ..finishBytes();
      p.step(TransferPhase.verifying, commit: true);
      expect(p.state.phase, TransferPhase.verifying);
      expect(p.state.percentage, 100);
      expect(p.state.confirmed, isFalse);
    });
    test('08 completion requires an engine-validated receipt boundary', () {
      final p = ProgressProbe()
        ..start()
        ..finishBytes();
      p.step(TransferPhase.completed);
      expect(p.state.confirmed, isFalse);
      expect(p.state.terminal, isFalse);
      p.controller.completeFromReceipt(p.epoch, p.attempt, p.receipt());
      expect(p.state.phase, TransferPhase.completed);
      expect(p.state.successfulFiles, 1);
    });
    test('09 definitive failure preserves real byte counts', () {
      final p = ProgressProbe()..start();
      p.step(TransferPhase.sending, bytes: 45, fileBytes: 45);
      p.controller.finishFailure(
        p.epoch,
        const TransferException('File read failed.'),
      );
      expect(p.state.phase, TransferPhase.failed);
      expect(p.state.batchBytes, 45);
      expect(p.state.unsuccessfulFiles, 1);
    });
    test('10 requested cancellation is not prematurely terminal', () {
      final p = ProgressProbe()..start();
      p.controller.requestCancellation(p.epoch);
      expect(p.state.cancelRequested, isTrue);
      expect(p.state.terminal, isFalse);
      p.controller.finishFailure(p.epoch, const TransferCancelled());
      expect(p.state.phase, TransferPhase.canceled);
    });
    test(
      '11 zero-byte file uses staged-file completion without division by zero',
      () {
        final p = ProgressProbe(sizes: <int>[0])..start();
        expect(p.state.fraction, 0);
        p.finishBytes();
        expect(p.state.percentage, 100);
        expect(p.state.confirmed, isFalse);
        p.step(TransferPhase.completed, receipt: p.receipt());
        expect(p.state.confirmed, isTrue);
        expect(p.state.batchBytes, 0);
      },
    );
    test('12 single-file name index and byte totals', () {
      final p = ProgressProbe(sizes: <int>[72])..start();
      p.step(TransferPhase.sending, bytes: 20, fileBytes: 20);
      expect(p.state.fileName, 'file-0.bin');
      expect(p.state.currentFileNumber, 1);
      expect(p.state.fileTotalBytes, 72);
    });
    test('13 multiple files keep cumulative bytes and separate file bytes', () {
      final p = ProgressProbe(sizes: <int>[100, 200])..start();
      p.step(
        TransferPhase.sending,
        bytes: 100,
        fileBytes: 100,
        done: 1,
        checked: 1,
      );
      p.step(TransferPhase.preparing, index: 1, fileBytes: 0);
      p.step(TransferPhase.sending, bytes: 150, fileBytes: 50);
      expect(p.state.fileBytes, 50);
      expect(p.state.batchBytes, 150);
      expect(p.state.totalBytes, 300);
      expect(p.state.currentFileNumber, 2);
      expect(p.state.completedFiles, 1);
    });
    test('14 exactly 100 percent bytes does not imply delivery', () {
      final p = ProgressProbe()
        ..start()
        ..finishBytes();
      expect(p.state.fraction, 1);
      expect(p.state.successfulFiles, 0);
      expect(p.state.receipt, isNull);
    });
    test('15 invalid over-range and negative counters are safely bounded', () {
      final p = ProgressProbe()..start();
      p.step(TransferPhase.sending, bytes: -30, fileBytes: -20, done: -4);
      expect(p.state.batchBytes, 0);
      expect(p.state.fileBytes, 0);
      p.step(TransferPhase.sending, bytes: 9999, fileBytes: 9999, done: 99);
      expect(p.state.percentage, 100);
      expect(p.state.completedFiles, 1);
      expect(p.state.confirmed, isFalse);
      expect(p.state.warning, isNotNull);
    });
    test(
      '16 cancellation during transfer rejects duplicate cancel requests',
      () {
        final p = ProgressProbe()..start();
        expect(p.controller.requestCancellation(p.epoch), isTrue);
        expect(p.controller.requestCancellation(p.epoch), isFalse);
        p.controller.finishFailure(p.epoch, const TransferCancelled());
        expect(p.state.successfulFiles, 0);
      },
    );
    test('17 a real completion receipt wins a cancellation race', () {
      final p = ProgressProbe()
        ..start()
        ..finishBytes();
      p.controller.requestCancellation(p.epoch);
      p.controller.finishFailure(p.epoch, const TransferCancelled());
      expect(
        p.controller.completeFromReceipt(p.epoch, p.attempt, p.receipt()),
        isTrue,
      );
      expect(p.state.confirmed, isTrue);
      expect(p.state.cancelRequested, isTrue);
    });
    test('18 commit ambiguity never guesses success or failure counts', () {
      final p = ProgressProbe()
        ..start()
        ..finishBytes();
      p.step(TransferPhase.verifying, commit: true);
      p.controller.finishFailure(
        p.epoch,
        const TransferException('Confirmation lost.', outcomeUncertain: true),
      );
      p.controller.settle(p.epoch);
      expect(p.state.successfulFiles, isNull);
      expect(p.state.unsuccessfulFiles, isNull);
      expect(p.state.canRetry, isFalse);
    });
    test('19 safe retry requires settled uncommitted work and a new epoch', () {
      final p = ProgressProbe()..start();
      final oldEpoch = p.epoch;
      final oldEvent = p.frame(TransferPhase.sending, bytes: 5, fileBytes: 5);
      p.controller.finishFailure(
        p.epoch,
        const TransferException('Connection failed.'),
      );
      expect(p.state.canRetry, isFalse);
      p.controller.settle(p.epoch);
      expect(p.state.canRetry, isTrue);
      p.epoch = p.controller.open(TransferRole.sender);
      expect(p.controller.addEngineEvent(oldEpoch, oldEvent), isFalse);
      expect(p.state.phase, TransferPhase.idle);
    });
    test('20 file-count progress cannot regress', () {
      final p = ProgressProbe(sizes: <int>[10, 20])..start();
      p.step(TransferPhase.sending, bytes: 10, fileBytes: 10, done: 1);
      expect(p.step(TransferPhase.sending, done: 0), isFalse);
      expect(p.state.completedFiles, 1);
    });
    test('21 byte-count progress cannot regress', () {
      final p = ProgressProbe()..start();
      p.step(TransferPhase.sending, bytes: 100, fileBytes: 100);
      expect(p.step(TransferPhase.sending, bytes: 80, fileBytes: 80), isFalse);
      expect(p.state.batchBytes, 100);
    });
    test(
      '22 speed is measured from monotonic elapsed time and actual bytes',
      () {
        final p = ProgressProbe()..start();
        p.time = const Duration(seconds: 2);
        p.step(TransferPhase.sending, bytes: 200, fileBytes: 200);
        expect(p.state.bytesPerSecond, closeTo(100, 0.001));
      },
    );
    test(
      '23 ETA estimates only the remaining payload and expires on stalls',
      () {
        final p = ProgressProbe()..start();
        p.time = const Duration(seconds: 2);
        p.step(TransferPhase.sending, bytes: 200, fileBytes: 200);
        expect(p.state.eta, const Duration(seconds: 8));
        p.time = const Duration(seconds: 6);
        p.controller.refreshEstimates();
        expect(p.state.bytesPerSecond, 0);
        expect(p.state.eta, isNull);
        expect(p.state.batchBytes, 200);
      },
    );
    test('24 malformed verification receipts cannot confirm delivery', () {
      final p = ProgressProbe()
        ..start()
        ..finishBytes();
      p.step(TransferPhase.completed, receipt: p.receipt(digest: 'not-a-hash'));
      expect(p.state.confirmed, isFalse);
      expect(p.state.warning, contains('receipt'));
    });
    test('29 duplicate and stale progress frames are ignored', () {
      final p = ProgressProbe()..start();
      final event = p.frame(TransferPhase.sending, bytes: 10, fileBytes: 10);
      expect(p.controller.addEngineEvent(p.epoch, event), isTrue);
      expect(p.controller.addEngineEvent(p.epoch, event), isFalse);
      expect(
        p.controller.addEngineEvent(
          p.epoch,
          event.copyWith(attemptId: randomTransferId(), sequence: 999),
        ),
        isFalse,
      );
      expect(p.state.batchBytes, 10);
    });
    test('30 inconsistent metadata indices totals and states do not corrupt progress', () {
      final p = ProgressProbe()..start();
      final wrongTotal = p
          .frame(TransferPhase.sending)
          .copyWith(totalBytes: 4000);
      expect(p.controller.addEngineEvent(p.epoch, wrongTotal), isFalse);
      expect(p.step(TransferPhase.sending, index: 8), isFalse);
      expect(p.step(TransferPhase.connecting), isFalse);
      expect(p.state.phase, TransferPhase.sending);
      expect(p.state.totalBytes, 1000);
    });
    test('repeated wire IDs have distinct receiver attempt identities', () {
      final p = ProgressProbe(role: TransferRole.receiver)
        ..start()
        ..finishBytes();
      p.step(TransferPhase.completed, receipt: p.receipt());
      final oldAttempt = p.attempt;
      p.attempt = randomTransferId();
      final event = TransferProgress(
        phase: TransferPhase.awaitingApproval,
        message: 'Next offer',
        transferId: p.id,
        attemptId: p.attempt,
        sequence: ++p.sequence,
        manifest: p.files,
        totalBytes: 1000,
        totalFiles: 1,
      );
      expect(p.controller.addEngineEvent(p.epoch, event), isTrue);
      expect(p.state.confirmed, isFalse);
      expect(
        p.controller.completeFromReceipt(p.epoch, oldAttempt, p.receipt()),
        isFalse,
      );
    });
    test(
      'public activity projection remains safe for malformed numerical inputs',
      () {
        final activity = TransferActivity(
          progress: const TransferProgress(
            phase: TransferPhase.sending,
            message: '',
            processedBytes: -10,
            totalBytes: -1,
            totalFiles: -5,
          ),
          measuredBytesPerSecond: double.nan,
          estimatedRemaining: const Duration(seconds: -1),
        );
        expect(activity.fraction, 0);
        expect(activity.totalFiles, 0);
        expect(activity.bytesPerSecond, isNull);
        expect(activity.eta, isNull);
      },
    );
    test('clock rollback and estimator refresh never create bytes', () {
      final p = ProgressProbe()..start();
      p.time = const Duration(seconds: 2);
      p.step(TransferPhase.sending, bytes: 200, fileBytes: 200);
      p.time = const Duration(seconds: 1);
      p.controller.refreshEstimates();
      expect(p.state.batchBytes, 200);
      expect(p.state.bytesPerSecond, isNull);
    });
    test(
      'disposed controller ignores queued progress receipts and cancellation',
      () {
        final p = ProgressProbe()..start();
        final event = p.frame(TransferPhase.sending, bytes: 1, fileBytes: 1);
        p.controller.dispose();
        expect(p.controller.addEngineEvent(p.epoch, event), isFalse);
        expect(
          p.controller.completeFromReceipt(p.epoch, p.attempt, p.receipt()),
          isFalse,
        );
        expect(p.controller.requestCancellation(p.epoch), isFalse);
      },
    );
  });

  group('Part 4 malformed-event regressions', () {
    test('a rejected high sequence cannot poison later valid telemetry', () {
      final p = ProgressProbe()..start();
      final bad = p
          .frame(TransferPhase.sending)
          .copyWith(sequence: 999999, totalBytes: 9000);
      expect(p.controller.addEngineEvent(p.epoch, bad), isFalse);
      expect(p.step(TransferPhase.sending, bytes: 30, fileBytes: 30), isTrue);
      expect(p.state.batchBytes, 30);
    });
    test(
      'current-file counters cannot go backwards while batch counters advance',
      () {
        final p = ProgressProbe()..start();
        p.step(TransferPhase.sending, bytes: 100, fileBytes: 100);
        expect(
          p.step(TransferPhase.sending, bytes: 110, fileBytes: 90),
          isFalse,
        );
        expect(p.state.fileBytes, 100);
      },
    );
    test('malformed hash-check counts cannot invent matched checksums', () {
      final p = ProgressProbe()..start();
      p.step(
        TransferPhase.sending,
        bytes: 1000,
        fileBytes: 1000,
        done: 1,
        checked: 999,
      );
      expect(p.state.verifiedFiles, 0);
      expect(p.state.confirmed, isFalse);
    });
  });

  group('Part 4 real TLS progress', () {
    late TlsIdentity identity;
    HttpOverrides? previous;
    setUpAll(() async {
      identity = await TlsIdentity.generate();
    });
    setUp(() {
      previous = HttpOverrides.current;
      HttpOverrides.global = null;
    });
    tearDown(() {
      HttpOverrides.global = previous;
    });

    test(
      '25 receiver completion uses existing saved history and receipt',
      () async {
        final controller = TransferProgressController(autoRefresh: false);
        addTearDown(controller.dispose);
        final epoch = controller.open(TransferRole.receiver);
        final phases = <TransferPhase>{};
        final receiver = await baseline.startReceiverFixture(
          identity,
          progress: (event) {
            phases.add(event.phase);
            expect(controller.addEngineEvent(epoch, event), isTrue);
          },
        );
        await LocalSender().send(
          code: receiver.code,
          files: <ShareFile>[
            baseline.bytesFile('one.txt', <int>[1, 2]),
            baseline.bytesFile('empty.txt', <int>[]),
          ],
          senderName: 'Progress integration',
        );
        expect(controller.value.confirmed, isTrue);
        expect(controller.value.verifiedFiles, 2);
        expect(
          phases,
          containsAll(<TransferPhase>[
            TransferPhase.approved,
            TransferPhase.preparing,
            TransferPhase.receiving,
            TransferPhase.verifying,
            TransferPhase.completed,
          ]),
        );
        final history = await TransferHistoryService(receiver.root).load();
        expect(
          history.transfers.single.receipt.id,
          controller.value.receipt!.id,
        );
      },
    );
    test(
      '26 sender confirmation and counters use real TLS engine events',
      () async {
        final receiver = await baseline.startReceiverFixture(identity);
        final controller = TransferProgressController(autoRefresh: false);
        addTearDown(controller.dispose);
        final epoch = controller.open(TransferRole.sender);
        final stages = <int>[];
        final receipt = await LocalSender().send(
          code: receiver.code,
          files: <ShareFile>[
            baseline.bytesFile('a.txt', <int>[1]),
            baseline.bytesFile('b.txt', <int>[2, 3]),
          ],
          senderName: 'Sender',
          onProgress: (event) {
            expect(controller.addEngineEvent(epoch, event), isTrue);
            stages.add(event.completedFiles);
          },
        );
        expect(controller.value.receipt, same(receipt));
        expect(controller.value.batchBytes, 3);
        expect(stages, containsAll(<int>[0, 1, 2]));
      },
    );
    test('real approval denial reads no source and remains retryable only after settlement', () async {
      final receiver = await baseline.startReceiverFixture(
        identity,
        approve: (_) async => false,
      );
      final controller = TransferProgressController(autoRefresh: false);
      addTearDown(controller.dispose);
      final epoch = controller.open(TransferRole.sender);
      var reads = 0;
      try {
        await LocalSender().send(
          code: receiver.code,
          files: <ShareFile>[
            baseline.sampleFile(
              size: 3,
              openRead: () {
                reads += 1;
                return Stream<List<int>>.value(<int>[1, 2, 3]);
              },
            ),
          ],
          senderName: 'Denied',
          onProgress: (event) => controller.addEngineEvent(epoch, event),
        );
        fail('A declined batch must not complete.');
      } on TransferException catch (error) {
        controller.finishFailure(epoch, error);
      }
      expect(reads, 0);
      expect(controller.value.canRetry, isFalse);
      controller.settle(epoch);
      expect(controller.value.canRetry, isTrue);
    });
    test('real streamed cancellation keeps original content and records no saved success', () async {
      final receiver = await baseline.startReceiverFixture(identity);
      final controller = TransferProgressController(autoRefresh: false);
      addTearDown(controller.dispose);
      final epoch = controller.open(TransferRole.sender);
      final sender = LocalSender();
      final source = ShareFile(
        name: 'cancel.bin',
        size: 4,
        sourceUri: Uri.file('/selected/cancel.bin'),
        readStream: () async* {
          yield <int>[1, 2];
          await Future<void>.delayed(const Duration(milliseconds: 30));
          yield <int>[3, 4];
        },
      );
      try {
        await sender.send(
          code: receiver.code,
          files: <ShareFile>[source],
          senderName: 'Cancel test',
          onProgress: (event) {
            controller.addEngineEvent(epoch, event);
            if (event.processedBytes > 0 && !controller.value.cancelRequested) {
              controller.requestCancellation(epoch);
              sender.cancel();
            }
          },
        );
        fail('Canceled streaming must not complete.');
      } on TransferException catch (error) {
        controller.finishFailure(epoch, error);
      }
      controller.settle(epoch);
      expect(controller.value.phase, TransferPhase.canceled);
      expect(controller.value.successfulFiles, 0);
      expect(
        (await TransferHistoryService(receiver.root).load()).transfers,
        isEmpty,
      );
    });
    test('real source failure has no false successful-file count', () async {
      final receiver = await baseline.startReceiverFixture(identity);
      final controller = TransferProgressController(autoRefresh: false);
      addTearDown(controller.dispose);
      final epoch = controller.open(TransferRole.sender);
      try {
        await LocalSender().send(
          code: receiver.code,
          files: <ShareFile>[
            baseline.bytesFile('short.txt', <int>[1], declaredSize: 2),
          ],
          senderName: 'Short source',
          onProgress: (event) => controller.addEngineEvent(epoch, event),
        );
        fail('A short stream must fail.');
      } on TransferException catch (error) {
        controller.finishFailure(epoch, error);
      }
      expect(controller.value.phase, TransferPhase.failed);
      expect(controller.value.batchBytes, 1);
      expect(controller.value.successfulFiles, 0);
    });
  });

  group('Part 4 widgets and lifecycle', () {
    testWidgets('progress fits narrow screens with large system text', (
      tester,
    ) async {
      final p = ProgressProbe(sizes: <int>[10, 20])..start();
      tester.view.physicalSize = const Size(320, 740);
      tester.view.devicePixelRatio = 1;
      tester.binding.platformDispatcher.textScaleFactorTestValue = 2;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      addTearDown(
        tester.binding.platformDispatcher.clearTextScaleFactorTestValue,
      );
      await tester.pumpWidget(
        MaterialApp(
          home: Scaffold(
            body: SingleChildScrollView(
              child: TransferProgressPanel(
                controller: p.controller,
                onCancel: () => p.controller.requestCancellation(p.epoch),
              ),
            ),
          ),
        ),
      );
      await tester.pump();
      expect(tester.takeException(), isNull);
      expect(find.text('File 1 of 2'), findsOneWidget);
    });
    testWidgets(
      '27 disposing progress widget detaches without owning the engine',
      (tester) async {
        final p = ProgressProbe()..start();
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: SingleChildScrollView(
                child: TransferProgressPanel(controller: p.controller),
              ),
            ),
          ),
        );
        await tester.pumpWidget(const SizedBox.shrink());
        p.step(TransferPhase.sending, bytes: 10, fileBytes: 10);
        await tester.pump();
        expect(tester.takeException(), isNull);
        expect(p.state.batchBytes, 10);
      },
    );
    testWidgets('28 backgrounding Nearby cancels its real sender interface', (
      tester,
    ) async {
      final sender = ControlledSender();
      await mountSender(tester, sender);
      expect(find.text('Waiting for approval'), findsOneWidget);
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.paused);
      await tester.pumpAndSettle();
      expect(sender.cancellations, greaterThan(0));
      expect(find.text('Cancelled'), findsWidgets);
      tester.binding.handleAppLifecycleStateChanged(AppLifecycleState.resumed);
      await tester.pumpAndSettle();
      expect(find.text('Delivery confirmed'), findsNothing);
    });
    testWidgets('disposing Nearby cancels work and ignores late callbacks', (
      tester,
    ) async {
      final sender = ControlledSender();
      await mountSender(tester, sender);
      await tester.pumpWidget(const SizedBox.shrink());
      await tester.pump();
      sender.emit(TransferPhase.sending);
      await tester.pump();
      expect(sender.cancellations, greaterThan(0));
      expect(tester.takeException(), isNull);
    });
    testWidgets(
      'a confirmed sender result retains the existing delivery receipt UI',
      (tester) async {
        final sender = ControlledSender();
        await mountSender(tester, sender);
        sender.confirm();
        await tester.pumpAndSettle();
        expect(
          find.byKey(const ValueKey('transfer-result-panel')),
          findsOneWidget,
        );
        expect(find.text('Successful files: 1'), findsOneWidget);
        await tester.scrollUntilVisible(
          find.text('Delivery confirmed'),
          250,
          scrollable: find.byType(Scrollable).first,
        );
        expect(find.text('Delivery confirmed'), findsOneWidget);
      },
    );
    testWidgets(
      'receiver result opens the existing HistoryScreen instead of a second database',
      (tester) async {
        final p = ProgressProbe(role: TransferRole.receiver)
          ..start()
          ..finishBytes();
        p.step(TransferPhase.completed, receipt: p.receipt());
        final root = await tester.runAsync(
          () => Directory.systemTemp.createTemp('part4-history-ui-'),
        );
        addTearDown(() async {
          await root!.delete(recursive: true);
        });
        await tester.pumpWidget(
          MaterialApp(
            home: Builder(
              builder: (context) => Scaffold(
                body: SingleChildScrollView(
                  child: TransferResultPanel(
                    activity: p.state,
                    onDone: () => Navigator.pop(context),
                    onViewSavedFiles: () => Navigator.push<void>(
                      context,
                      MaterialPageRoute<void>(
                        builder: (context) => HistoryScreen(
                          service: baseline.FakeHistoryService(
                            HistorySnapshot(transfers: []),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
        await tester.pumpAndSettle();
        await baseline.tapVisibleKey(
          tester,
          const ValueKey('result-view-saved-files'),
        );
        expect(find.byKey(const ValueKey('history-scaffold')), findsOneWidget);
      },
    );
    testWidgets(
      'safe retry is explicit and does not discard selected originals',
      (tester) async {
        final sender = ControlledSender();
        await mountSender(tester, sender);
        sender.fail();
        await tester.pumpAndSettle();
        await tester.scrollUntilVisible(
          find.byKey(const ValueKey('retry-uncommitted-transfer')),
          200,
          scrollable: find.byType(Scrollable).first,
        );
        await baseline.tapVisibleKey(
          tester,
          const ValueKey('retry-uncommitted-transfer'),
        );
        expect(find.text('Retry the uncommitted batch?'), findsOneWidget);
        await tester.tap(find.text('Not now'));
        await tester.pumpAndSettle();
        expect(sender.sequence, 2);
      },
    );
    testWidgets(
      'uncertain result never offers automatic retry or invented counts',
      (tester) async {
        final p = ProgressProbe()
          ..start()
          ..finishBytes();
        p.step(TransferPhase.verifying, commit: true);
        p.controller.finishFailure(
          p.epoch,
          const TransferException(
            'Receipt unavailable.',
            outcomeUncertain: true,
          ),
        );
        p.controller.settle(p.epoch);
        await tester.pumpWidget(
          MaterialApp(
            home: Scaffold(
              body: SingleChildScrollView(
                child: TransferResultPanel(
                  activity: p.state,
                  onDone: () {},
                  onRetry: () {},
                ),
              ),
            ),
          ),
        );
        expect(find.text('Successful files: Unknown'), findsOneWidget);
        expect(
          find.byKey(const ValueKey('retry-uncommitted-transfer')),
          findsNothing,
        );
      },
    );
  });
}
