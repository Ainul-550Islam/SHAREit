# ShareBondhu — Part 4 (File 16–20)

Version **0.4.0+4**. This part adds reliable transfer progress and result UI on the authoritative Part 3 implementation. It does not add settings, branding changes, a replacement transfer engine, a new history database, or Part 5 code.

## New functionality

- The existing `TransferPhase` enum now also represents idle, approved and preparing. No second wire-state enum is introduced.
- Existing `TransferProgress` callbacks carry local-only attempt identity, sequence, approved manifest, current-file counters, checked-hash count, commit boundary and the already-validated completion receipt.
- A controller projects those real engine events into bounded UI state, current-file/batch bytes, staged-file count, payload percentage, recent payload rate and payload-only ETA.
- A 500 ms estimator refresh may age the rate/ETA during a stall. It never increments bytes, file counts, verification counts or percentage.
- Cancel is a request until the engine finishes. A validated completion receipt can win a cancellation race. Uploaded bytes alone never produce delivery confirmation.
- The result panel distinguishes confirmed files from an uncommitted/rolled-back batch and an unknown final outcome. Safe retry is a user-confirmed new attempt of an entire uncommitted batch, not partial resume.
- The old receipt/export panel remains in the result UI. Receiver View Saved Files opens the existing HistoryScreen after an explicit stop-session confirmation when necessary.

## Files

| Number | Path | State |
|---|---|---|
| 16 | `lib/models/transfer_activity.dart` | NEW — view projection of existing TransferProgress |
| 17 | `lib/services/transfer_progress_controller.dart` | NEW — real-event normalization, rates, ETA, lifecycle guards |
| 18 | `lib/widgets/transfer_progress_panel.dart` | NEW — sender/receiver progress UI |
| 19 | `lib/widgets/transfer_result_panel.dart` | NEW — receipt-aware result and actions |
| 20 | `test/transfer_progress_test.dart` | NEW — Part 4 tests; original test file retained |
| 1 | `pubspec.yaml` | UPDATED — version only |
| 6 | `lib/models/transfer_models.dart` | UPDATED — additive phases and optional local telemetry fields/copyWith |
| 7 | `lib/services/local_transfer_service.dart` | UPDATED — in-process instrumentation; original TLS/transfer functions retained |
| 8 | `lib/screens/nearby_screen.dart` | UPDATED — controller wiring, cancellation/result/retry/history actions |

Files 2–5 and 9–15, and `pubspec.lock`, are byte-identical to Part 3. Full replacement source for every numbered file is in `docs/PART_04_FULL_CODE.md`; the source archive also contains the complete Android/iOS scaffold.

## Dependencies and native changes

**No new dependency.** Every pinned dependency from Part 3 is retained. No Android/iOS permission, native plugin, application ID or platform configuration was changed for Part 4.

Tested toolchain: Flutter **3.47.2** / Dart **3.13.2**, Linux. Minimum constraints remain Flutter 3.47.0 / Dart 3.13.0. Android generated target/compile SDK is 36, minimum SDK 24; iOS deployment target is 15.0. Android builds require a compatible JDK 17+ and Android SDK. iPhone building requires a Mac, compatible Xcode and signing setup.

```bash
flutter pub get
flutter analyze
flutter test
flutter run
```

A hot restart is recommended so an existing in-memory transfer session is not retained across the code update. A native full stop/rebuild is not newly required solely by Part 4, because no plugin/permission changed. If Part 3's camera/native dependencies were never built into the installed app, rebuild those first.

## Automated verification

- Previous documented baseline: **97 tests**.
- New Part 4 tests: **46**.
- Actually run: `flutter analyze --no-pub` — **No issues found**.
- Actually run: `flutter test --no-pub --reporter expanded` — **143 tests passed**.
- New tests include 33 controller/model/malformed-event cases, 5 real loopback TLS integrations and 8 UI/lifecycle cases.
- Real network tests use actual TLS sockets, receiver approval callbacks, streamed bytes, disk writes and receipt/history checks on one computer. UI tests use controlled sender/share/storage test seams where native APIs are unavailable.
- Source comparison confirmed the retained baseline files and all preexisting classes/enums/method names in the updated engine/model/screen files.

These results are not Android/iPhone device, real-camera, two-phone Wi-Fi, native build, production signing or store verification. Logs are in `docs/PART_04_TEST_RESULTS.txt`.

## Existing security and behavior retained

The same SB1 code, five v1 routes, certificate-pinned TLS, invitation/upload authentication, native-local request checks, receiver approval, exact lengths, streaming, SHA-256 comparisons, final receipt validation, atomic batch commit, cleanup and lost-receipt recovery remain. No HTTP fallback, redirect/proxy workaround, browser URL launch, checksum bypass or automatic acceptance was introduced.

QR still only fills a pairing code. Sender still presses Ask to send; receiver still accepts explicitly. File selection and original-file preservation, camera/foreground lifecycle handling, history, explicit history checksum checking and native share flows remain.

Limits remain **50 files**, **2 GiB/file**, **4 GiB/batch**, **10-minute invitations**, **60-second receiver approval**. Existing sender/idle/batch timeouts remain in the TLS engine.

The one conservative commit-boundary adjustment marks commit as possible before its body is queued. This prevents offering an unsafe automatic retry if cancellation races with sending that body. It changes no route or wire payload and may report an uncertain outcome rather than guessing that nothing was saved.

## Manual/device test — Android to Android

This checklist is **not executed by the automated tests**.

1. Build/install on two real Android phones. Use the same trusted private IPv4 Wi-Fi or a hotspot permitting device-to-device traffic. Keep both apps foregrounded.
2. Receiver: Home → Receive files → Start receiving. Sender: select a small local text/photo file → Send selected. Use the full manual code, then repeat later with QR → Start camera → Use this code.
3. Confirm scanning alone sends nothing. Tap Ask to send. Confirm the sender waits and no content starts before the receiver accepts. Decline once and check no saved batch is created.
4. Accept a small file. Check names, File 1 of 1, file/batch bytes and counts. Wait for the validated receipt, not just 100% bytes. Compare the received copy and run Saved files → Verify checksums.
5. Send multiple files, including a zero-byte file and two same-named files from different sources. Check file number, current-file reset, cumulative bytes and staged-file counts. Verify the entire batch and distinct received copies.
6. Use a larger local file within the existing limits so progress can be observed. Check recent payload rate and ETA; they are estimates of bytes only, not total finish time.
7. Cancel midway from the sender, then in another run from the receiver. Wait for engine settlement. Original selected files must remain; an uncommitted batch must not appear as delivered. Use Retry uncommitted batch only when offered; confirm a new receiver approval is required.
8. Cancel near completion and briefly interrupt connectivity around final confirmation. A commit may already have won. If the outcome is unknown, check receiver Saved files before any retry; never infer failure from missing confirmation alone.
9. Background/lock either phone during an active transfer, return, and verify the operation stops rather than silently resuming. Start a fresh session when ready.
10. On a confirmed receiver result, use View Saved Files. Confirm the stop-session prompt where relevant and that the old history screen opens. Verify and export a copy through the existing share sheet, checking the chosen destination yourself.

For iPhone interoperability, perform a separate real-device pass with local-network/camera permissions and iPad share anchoring where applicable. No iPhone result is claimed here.

## Known limitations

- Foreground, private IPv4 LAN/hotspot transfer only. No resume, automatic hotspot/discovery, IPv6-only sharing or background service.
- Progress measures local payload writes/flushes and staged-file acknowledgments, not durable delivery. Rate is a recent estimate; tiny transfers may finish before a useful estimate exists. ETA excludes approval, verification, storage commit and receipt recovery.
- The protocol commits all files as one batch. No partial-success or retry-only-one-failed-upload feature is invented. Unsuccessful counts include unattempted/rolled-back files; ambiguous outcomes show unknown counts.
- Cancellation cannot retract already committed files. A lost final receipt may require checking the receiver manually. No automatic retry is offered for an uncertain commit.
- Live progress is in-memory, not a persistent transfer/resume queue. Existing received-file history and its bounded read-only scan remain unchanged.
- Native/device/build/store verification, release signing, final launcher branding and independent security audit remain unperformed. There is no added at-rest encryption, signed history receipt or ad SDK.

# ▶ Next — Part 5 (File 21–25)
