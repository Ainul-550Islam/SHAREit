# ShareBondhu — permanent file index, after Part 4

## Standing delivery rules

Provide complete code files, not abbreviated implementations or patch-only deliverables. Preserve previous classes, functions, endpoints, validators, platform integration and tests. New authored files get sequential permanent numbers. Existing files retain their numbers when updated. End at the requested part and offer Next; do not implement the following part automatically.

Platform: Flutter Android + iPhone. Brand: ShareBondhu. Part 4's authoritative objective is real transfer progress and result UI, not the earlier settings/branding proposal.

## File numbers

| File | Path | Part 4 status |
|---|---|---|
| 1 | `pubspec.yaml` | UPDATED — version 0.4.0+4 only |
| 2 | `lib/main.dart` | Retained |
| 3 | `lib/models/share_file.dart` | Retained |
| 4 | `lib/screens/home_screen.dart` | Retained |
| 5 | `test/widget_test.dart` | Retained, all 97 Part 3 tests |
| 6 | `lib/models/transfer_models.dart` | UPDATED — additive phases and local telemetry fields |
| 7 | `lib/services/local_transfer_service.dart` | UPDATED — real-event instrumentation; original TLS engine retained |
| 8 | `lib/screens/nearby_screen.dart` | UPDATED — progress/result wiring and safe actions |
| 9 | `android/app/src/main/AndroidManifest.xml` | Retained |
| 10 | `ios/Runner/Info.plist` | Retained |
| 11 | `lib/models/saved_transfer.dart` | Retained |
| 12 | `lib/services/transfer_history_service.dart` | Retained |
| 13 | `lib/screens/history_screen.dart` | Retained |
| 14 | `lib/widgets/pairing_qr_card.dart` | Retained |
| 15 | `lib/screens/scan_pairing_screen.dart` | Retained |
| 16 | `lib/models/transfer_activity.dart` | NEW — UI projection of existing engine progress |
| 17 | `lib/services/transfer_progress_controller.dart` | NEW — event validation, counters, rates, ETA and outcome handling |
| 18 | `lib/widgets/transfer_progress_panel.dart` | NEW — sender/receiver progress panel |
| 19 | `lib/widgets/transfer_result_panel.dart` | NEW — receipt-aware result panel |
| 20 | `test/transfer_progress_test.dart` | NEW — 46 Part 4 tests |

Standard scaffold, assets, plugin registrants, lockfile and documentation are included in the archive inventory. Keep the numbering stable. Assign a new number to an unnumbered scaffold source only when it is customized by hand.

## Verified baseline

Date: 2026-09-08. Flutter 3.47.2 / Dart 3.13.2, Linux. Version 0.4.0+4.

No new dependency or native permission/plugin change in Part 4. Files 2–5, 9–15 and pubspec.lock are byte-identical to Part 3. All existing class/enum/method names in updated Files 6–8 were retained.

Automated verification: clean flutter analyze and 143 passing tests, consisting of the retained 97 and 46 new tests. New coverage: 33 controller/model/malformed-event tests, 5 actual loopback TLS integrations and 8 UI/lifecycle tests. Controlled sender/storage/share seams are test-only; real NearbyScreen defaults still use the existing TLS engine.

No native Android/iOS build, production build, real phone/camera, two-phone Wi-Fi, share-sheet or store verification is claimed. There is no APK/IPA deliverable.

## Compatibility contracts to preserve

- ShareBondhuApp picker injection and theme handling remain. HomeScreen keeps selection, three tabs, picker/theme callbacks and its default/injectable history builder.
- ShareFile still has sourceUri identity, a lazy readStream factory and openRead. Selection/removal/clear do not read or delete originals. Same-name/different-URI files remain allowed. Keep cancellation/error/busy/mounted protections.
- Keep complete SB1 manual codes, QR display/scanning and private IPv4 validation. QR only fills a code. Sender still asks to send; receiver still explicitly approves. No arbitrary scanned URL is opened.
- Keep fresh per-session TLS identity, exact certificate pin/host/port checking, empty trust roots, DIRECT/no redirects, local-native request checks and separate invitation/upload tokens. Never log codes, private keys or original source paths.
- Keep all five v1 endpoints, wire fields and protocol version. PROTOCOL_V1.md is the immutable original wire specification. The progress fields introduced here are in-process only and are not serialized to peers.
- Limits remain 50 files, 2 GiB per file, 4 GiB per batch, 10-minute invitations and 60-second receiver approval. Existing sender/idle/batch deadlines stay in the engine.
- Keep streamed hashing, exact-length checks, bounded JSON, per-file acknowledgments, final validated receipt, atomic batch commit and cleanup. The sender's owned StreamIterator must be canceled before hash disposal. Do not restore an unowned async-generator/addStream upload pump.
- Cancellation cannot retract a confirmed commit. Missing final confirmation is an uncertain outcome, not proof of failure. No blind retry.
- History reads app Documents/ShareBondhu/Received and existing v1 receipts without migration or mutation. Folder identity differs from sender-chosen wire batch ID. Keep safe path derivation, symlink/canonical-path checks, bounded scans and warnings.
- History availability checks size, not content; explicit verify/re-share checks SHA-256. Do not add a second database or silently delete/repair receipts. Share-sheet closure does not prove an external save. Keep iPad share origins.
- Preserve the separate PageStorageKey on each selectable checksum inside its ExpansionTile; otherwise text scrolling collides with boolean expansion-state storage.
- Keep optional camera permission, manual fallback, camera-off entry, no auto restart on resume, late-startup/disposal guards and no image-save/upload action. Do not remove existing Android/iOS permissions or scene configuration.

## Part 4 progress contracts

- Reuse TransferPhase and TransferProgress. idle, approved and preparing were appended to the existing enum; old values/order remain. TransferActivity is a presentation projection, not a new transfer protocol.
- Local telemetry includes transferId, attemptId, sequence, immutable approved manifest, zero-based file index, current-file bytes/size, cumulative payload bytes, staged-file count, verified-file count, commitStarted and an optional engine-validated receipt.
- Receiver attemptId is fresh per offer, independent of the wire ID. This permits repeated wire IDs without letting late callbacks overwrite another attempt. Sender events use the outgoing offer ID; controller epochs distinguish runs.
- Connecting/approval events occur before any file stream. Preparation/open, actual sender flush/receiver write, file acknowledgment and hash-comparison events supply the counters. Zero-byte files have explicit start/ack events.
- Controller rejects stale epochs/attempts/sequences, inconsistent totals/indices, illegal state regressions, backward file/batch counters and malformed receipts. Invalid bounded numeric input cannot create a success receipt. Invalid high-sequence frames do not poison future valid telemetry.
- Completion comes from the engine's already-validated receipt, not 100 percent bytes. completeFromReceipt adds structural consistency checks; it does not replace the engine's SHA-256/authentication checks. A late valid receipt can supersede a cancellation request.
- Rate is based on monotonic time and recent real payload deltas. The 500 ms timer refreshes estimates only. It never advances bytes, counts or percentage. A stall produces zero rate/unknown ETA. ETA excludes approval, verification, commit and receipt recovery.
- Cancellation requests do not immediately become terminal. Retry requires settled, known-uncommitted sender work and a new user-approved attempt. Unknown commit outcomes have unknown result counts and no automatic retry option.
- One conservative engine change marks commit as possible before queuing its body, preventing false safe-retry classification during a cancellation race. No endpoint/wire-format change accompanies it.
- NearbyScreen owns the controller, retains all older functions/panels, and wires the actual engine callbacks. Its optional senderFactory is for tests; the default is LocalSender.new. Background/disposal still stop the actual work.
- TransferProgressPanel listens but does not own or stop the engine on its own disposal. Scrolling a panel out of view must not cancel a transfer. TransferResultPanel embeds the old receipt/export panel and opens existing history through the screen's guarded actions.

## Next

Next new file is **File 21**. Part 5 has not been implemented. Keep all versioned archives/full-code guides immutable, and obtain the next objective before adding unrelated functionality. Native/device/release verification and existing foreground/IPv4/no-resume limitations remain explicitly outstanding.
